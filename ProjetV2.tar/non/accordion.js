// ==========================================================
// accordion.js — Version améliorée avec auto-redimensionnement
// ==========================================================

// Gestion ouverture/fermeture
document.querySelectorAll(".accordion-btn").forEach(btn => {
    btn.addEventListener("click", () => {
        const panel = btn.nextElementSibling;

        // Fermer les autres panneaux
        document.querySelectorAll(".accordion-panel").forEach(p => {
            if (p !== panel) {
                p.style.maxHeight = null;
                p.classList.remove("active");
            }
        });

        // Ouvrir / fermer celui cliqué
        if (panel.classList.contains("active")) {
            panel.style.maxHeight = null;
            panel.classList.remove("active");
        } else {
            panel.classList.add("active");
            panel.style.maxHeight = panel.scrollHeight + "px";
        }
    });
});

/* ==========================================================
   Fonction utilitaire appelée après chaque mise à jour
   pour recalculer la hauteur du panneau actif.
   ========================================================== */
function resizeAccordion(editorSelector) {
    const editor = document.querySelector(editorSelector);
    if (!editor) return;

    const panel = editor.closest(".accordion-panel");
    if (!panel) return;

    if (panel.classList.contains("active")) {
        panel.style.maxHeight = "none"; // reset
        panel.style.maxHeight = panel.scrollHeight + "px"; // recalcule
    }
}
