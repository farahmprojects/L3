// ==============================================
// tests.js — moteur de test + suite complète
// ==============================================


// ----------------------------------------------------
// ASSERTIONS
// ----------------------------------------------------
function assert(condition, message) {
    if (!condition) {
        console.error("❌ TEST FAILED → " + message);
    } else {
        console.log("✅ " + message);
    }
}

function assertEqual(actual, expected, message) {
    if (typeof actual === "number" && typeof expected === "number") {
        actual   = Number(actual.toFixed(2));
        expected = Number(expected.toFixed(2));
    }

    if (actual === expected) {
        console.log("✅ " + message);
    } else {
        console.error(
            `❌ TEST FAILED → ${message} (attendu: ${expected}, obtenu: ${actual})`
        );
    }
}

function assertHasKeys(obj, keys, msg) {
    const missing = keys.filter(k => !(k in obj));
    if (missing.length === 0) {
        console.log("✅ " + msg);
    } else {
        console.error(`❌ TEST FAILED → ${msg} | Manquants : ${missing.join(", ")}`);
    }
}



// ======================================================================
// 1️⃣ Tests des classes
// ======================================================================
function runTestClasses() {
    console.group("📦 Tests des classes");

    assert(typeof MenuItem === "function", "MenuItem défini");
    assert(typeof IceOption === "function", "IceOption défini");
    assert(typeof TypePrice === "function", "TypePrice défini");
    assert(typeof CartItem === "function", "CartItem défini");
    assert(typeof Cart === "function", "Cart défini");
    assert(typeof DataStore === "function", "DataStore défini");

    console.groupEnd();
}



// ======================================================================
// 2️⃣ Tests création d'objets
// ======================================================================
function runTestObjectCreation() {
    console.group("🧱 Tests création objets");

    const m = new MenuItem("Test", 3.5, "Desc");
    assertEqual(m.name, "Test", "MenuItem.name correct");
    assertEqual(m.price, 3.5, "MenuItem.price correct");

    const opt = new IceOption("Vanille", 0.5, true);
    assertEqual(opt.price, 0.5, "IceOption.price correct");

    const t = new TypePrice("Cône", "Cône", 3.0);
    assertEqual(t.basePrice, 3.0, "TypePrice.basePrice correct");

    console.groupEnd();
}



// ======================================================================
// 3️⃣ Tests panier
// ======================================================================
function runTestCart() {
    console.group("🛒 Tests panier");

    const c = new Cart([]);

    c.add(new CartItem("Cône", "1 boule", ["Vanille"], [], [], [], 3.0));
    assertEqual(c.items.length, 1, "Ajout panier OK");

    assertEqual(c.total(), 3.0, "Total correct");

    c.remove(0);
    assertEqual(c.items.length, 0, "Suppression OK");

    console.groupEnd();
}



// ----------------------------------------------------
// TESTS DATASTORE (robuste, supporte listes vides)
// ----------------------------------------------------
function runTestDataStore() {
    console.group("💾 Tests DataStore");

    // On teste la méthode publique loadFlavors()
    const fl = DataStore.loadFlavors([]);
    if (Array.isArray(fl)) {
        console.log("✅ DataStore.loadFlavors renvoie bien une liste");
    } else {
        console.error("❌ TEST FAILED → loadFlavors ne renvoie pas une liste");
    }

    const tp = DataStore.loadToppings([]);
    assert(Array.isArray(tp), "DataStore.loadToppings renvoie bien une liste");

    const fr = DataStore.loadFruits([]);
    assert(Array.isArray(fr), "DataStore.loadFruits renvoie bien une liste");

    const si = DataStore.loadSirops([]);
    assert(Array.isArray(si), "DataStore.loadSirops renvoie bien une liste");

    // Vérification que le premier élément (si présent) est bien une IceOption
    if (fl.length > 0) assert(fl[0].name !== undefined, "Flavors → premier élément valide");
    if (tp.length > 0) assert(tp[0].name !== undefined, "Toppings → premier élément valide");
    if (fr.length > 0) assert(fr[0].name !== undefined, "Fruits → premier élément valide");
    if (si.length > 0) assert(si[0].name !== undefined, "Sirops → premier élément valide");

    console.groupEnd();
}


// ======================================================================
// 5️⃣ Tests logique métier
// ======================================================================
function runTestLogic() {
    console.group("🧪 Tests logique prix et règles");

    const baseCone = new TypePrice("Cône", "Cône", 3.00);

    assertEqual(baseCone.basePrice + 0.5, 3.5, "Cône + parfum OK");

    assert(true, "Limite italienne → testée via UI");

    const prixRolls = 4.50 + 0.5 + 0.8 + 0.6;
    assertEqual(prixRolls, 6.40, "Rolls prix composé OK");

    console.groupEnd();
}



// ======================================================================
// 6️⃣ Tests approfondis des classes
// ======================================================================
function runTestDeepClasses() {
    console.group("🔍 Tests approfondis des classes");

    // MenuItem
    const mi = new MenuItem("Test", 4.2, "Desc");
    assertHasKeys(mi, ["name", "price", "desc"], "MenuItem → propriétés OK");
    assertHasKeys(mi.toJSON(), ["nom", "prix", "desc"], "MenuItem.toJSON OK");

    // IceOption
    const io = new IceOption("Pistache", 0.7, true);
    assertHasKeys(io, ["name", "price", "active"], "IceOption → propriétés OK");
    assertHasKeys(io.toJSON(), ["nom", "prix", "actif"], "IceOption.toJSON OK");

    // TypePrice
    const tp = new TypePrice("Pot", "Pot", 3);
    assertHasKeys(tp, ["id", "label", "basePrice"], "TypePrice → propriétés OK");
    assertHasKeys(tp.toJSON(), ["id", "label", "basePrice"], "TypePrice.toJSON OK");

    // CartItem
    const ci = new CartItem("Cône", "2 boules", ["Vanille"], ["Chantilly"], ["Banane"], ["Caramel"], 6);
    assertHasKeys(ci, ["type", "form", "flavors", "toppings", "fruits", "sirops", "price"], "CartItem → propriétés OK");
    assertHasKeys(ci.toJSON(), ["type", "forme", "flavors", "toppings", "fruits", "sirops", "price"], "CartItem.toJSON OK");

    console.groupEnd();
}



// ======================================================================
// 7️⃣ EXÉCUTE TOUS LES TESTS (bouton admin)
// ======================================================================
window.runAllTests = function () {
    console.clear();
    console.log("===== LANCEMENT DES TESTS =====");

    runTestClasses();
    runTestObjectCreation();
    runTestCart();
    runTestDataStore();
    runTestLogic();
    runTestDeepClasses();

    console.log("%c✔ Tous les tests ont été exécutés.", "color: green; font-weight: bold;");
};
