// =====================================================
// admin.js — Gestion complète du panneau administratif
// =====================================================

// ----------------------------
// Références DOM
// ----------------------------
const menuEditor    = document.getElementById("menu-editor");
const flavorEditor  = document.getElementById("parfum-editor");
const toppingEditor = document.getElementById("topping-editor");
const fruitEditor   = document.getElementById("fruit-editor");
const siropEditor   = document.getElementById("sirop-editor");
const typeEditor    = document.getElementById("type-editor");

const addItemBtn    = document.getElementById("addItem");
const addParfumBtn  = document.getElementById("addParfum");
const addToppingBtn = document.getElementById("addTopping");
const addFruitBtn   = document.getElementById("addFruit");
const addSiropBtn   = document.getElementById("addSirop");
const saveMenuBtn   = document.getElementById("saveMenu");
const goHomeBtn     = document.getElementById("goHome");

// ----------------------------
// Valeurs par défaut
// ----------------------------
const defaultMenu = [
    new MenuItem("Cône de Vanille", 3.50, "Crème glacée vanille classique"),
    new MenuItem("Boules de Chocolat", 2.50, "Boules de glace chocolat intense"),
    new MenuItem("Glace Italienne Fraise", 3.00, "Glace italienne à la fraise"),
    new MenuItem("Rolls Mangue Passion", 4.50, "Rolls glacés mangue et passion")
];

const defaultFlavors = [
    new IceOption("Vanille", 0.50, true),
    new IceOption("Chocolat", 0.50, true),
    new IceOption("Fraise", 0.50, true),
    new IceOption("Pistache", 0.70, true),
    new IceOption("Mangue", 0.70, true)
];

const defaultToppings = [
    new IceOption("Chantilly", 0.50, true),
    new IceOption("Caramel", 0.60, true),
    new IceOption("Pépites de chocolat", 0.70, true),
    new IceOption("Oréo", 0.80, true),
    new IceOption("Amandes", 0.70, true)
];

const defaultFruits = [
    new IceOption("Banane", 0.80, true),
    new IceOption("Fraise", 0.80, true),
    new IceOption("Mangue", 0.90, true),
    new IceOption("Kiwi", 0.90, true)
];

const defaultSirops = [
    new IceOption("Caramel", 0.60, true),
    new IceOption("Chocolat", 0.60, true),
    new IceOption("Fraise", 0.60, true),
    new IceOption("Fruit de la passion", 0.70, true)
];

const defaultTypePrices = [
    new TypePrice("Cône", "Cône", 3.00),
    new TypePrice("Pot", "Pot", 3.00),
    new TypePrice("Italienne", "Glace italienne", 3.00),
    new TypePrice("Rolls", "Glace Rolls", 4.50)
];

// ----------------------------
// Chargement depuis DataStore
// ----------------------------
let menu       = DataStore.loadMenu(defaultMenu);
let flavors    = DataStore.loadFlavors(defaultFlavors);
let toppings   = DataStore.loadToppings(defaultToppings);
let fruits     = DataStore.loadFruits(defaultFruits);
let sirops     = DataStore.loadSirops(defaultSirops);
let typePrices = DataStore.loadTypePrices(defaultTypePrices);

// =====================================================
//  FONCTIONS DE NETTOYAGE AUTOMATIQUE AVANT SAUVEGARDE
// =====================================================

// Supprime les MenuItem non modifiés
function nettoyerMenu() {
    menu = menu.filter(m =>
        !(m.name === "Nouveau produit" &&
          m.price === 0 &&
          m.desc === "Description")
    );
}

// Filtre générique pour IceOption
function nettoyerOptions(list, defaultName) {
    return list.filter(opt =>
        !(opt.name === defaultName &&
          opt.price === 0 &&
          opt.active === true)
    );
}

function nettoyerParfums() {
    flavors = nettoyerOptions(flavors, "Nouveau parfum");
}

function nettoyerToppings() {
    toppings = nettoyerOptions(toppings, "Nouveau topping");
}

function nettoyerFruits() {
    fruits = nettoyerOptions(fruits, "Nouveau fruit");
}

function nettoyerSirops() {
    sirops = nettoyerOptions(sirops, "Nouveau sirop");
}

// =====================================================
// AFFICHAGE DES SECTIONS ADMIN
// =====================================================

// ----------------------------
// MENU
// ----------------------------
function afficherMenu() {
    menuEditor.innerHTML = "";
    menu.forEach((m, i) => {
        menuEditor.innerHTML += `
        <div class="item">
            <span class="icon">📋</span>
            <input value="${m.name}" placeholder="Nom"
                onchange="menu[${i}].name = this.value">
            <input type="number" step="0.01" value="${m.price}"
                onchange="menu[${i}].price = parseFloat(this.value) || 0">
            <input value="${m.desc}" placeholder="Description"
                onchange="menu[${i}].desc = this.value">
            <button onclick="supprimerMenu(${i})">Supprimer</button>
        </div>`;
    });
}


const runTestsBtn = document.getElementById("run-tests");

if (runTestsBtn) {
    runTestsBtn.onclick = () => {
        if (typeof runAllTests === "function") {
            runAllTests();
        } else {
            alert("Erreur : tests.js n'est pas chargé.");
        }
    };
}



function supprimerMenu(i) {
    menu.splice(i, 1);
    afficherMenu();
}

addItemBtn.onclick = () => {
    menu.push(new MenuItem("Nouveau produit", 0, "Description"));
    afficherMenu();
};

// ----------------------------
// PARFUMS
// ----------------------------
function afficherParfums() {
    flavorEditor.innerHTML = "";
    flavors.forEach((p, i) => {
        flavorEditor.innerHTML += `
        <div class="item ${p.active ? "" : "inactive"}">
            <span class="icon">🍦</span>
            <input value="${p.name}" placeholder="Parfum"
                onchange="flavors[${i}].name = this.value">
            <input type="number" step="0.01" value="${p.price}"
                onchange="flavors[${i}].price = parseFloat(this.value) || 0">
            <label>
                <input type="checkbox" ${p.active ? "checked" : ""} onchange="toggleParfum(${i})">
                Disponible
            </label>
            <button onclick="supprimerParfum(${i})">Supprimer</button>
        </div>`;
    });
}

function toggleParfum(i) {
    flavors[i].active = !flavors[i].active;
    afficherParfums();
}

function supprimerParfum(i) {
    flavors.splice(i, 1);
    afficherParfums();
}

addParfumBtn.onclick = () => {
    flavors.push(new IceOption("Nouveau parfum", 0, true));
    afficherParfums();
};

// ----------------------------
// TOPPINGS
// ----------------------------
function afficherToppings() {
    toppingEditor.innerHTML = "";
    toppings.forEach((t, i) => {
        toppingEditor.innerHTML += `
        <div class="item ${t.active ? "" : "inactive"}">
            <span class="icon">🍫</span>
            <input value="${t.name}" placeholder="Topping"
                onchange="toppings[${i}].name = this.value">
            <input type="number" step="0.01" value="${t.price}"
                onchange="toppings[${i}].price = parseFloat(this.value) || 0">
            <label>
                <input type="checkbox" ${t.active ? "checked" : ""} onchange="toggleTopping(${i})">
                Disponible
            </label>
            <button onclick="supprimerTopping(${i})">Supprimer</button>
        </div>`;
    });
}

function toggleTopping(i) {
    toppings[i].active = !toppings[i].active;
    afficherToppings();
}

function supprimerTopping(i) {
    toppings.splice(i, 1);
    afficherToppings();
}

addToppingBtn.onclick = () => {
    toppings.push(new IceOption("Nouveau topping", 0, true));
    afficherToppings();
};

// ----------------------------
// FRUITS
// ----------------------------
function afficherFruits() {
    fruitEditor.innerHTML = "";
    fruits.forEach((f, i) => {
        fruitEditor.innerHTML += `
        <div class="item ${f.active ? "" : "inactive"}">
            <span class="icon">🍓</span>
            <input value="${f.name}" placeholder="Fruit"
                onchange="fruits[${i}].name = this.value">
            <input type="number" step="0.01" value="${f.price}"
                onchange="fruits[${i}].price = parseFloat(this.value) || 0">
            <label>
                <input type="checkbox" ${f.active ? "checked" : ""} onchange="toggleFruit(${i})">
                Disponible
            </label>
            <button onclick="supprimerFruit(${i})">Supprimer</button>
        </div>`;
    });
}

function toggleFruit(i) {
    fruits[i].active = !fruits[i].active;
    afficherFruits();
}

function supprimerFruit(i) {
    fruits.splice(i, 1);
    afficherFruits();
}

addFruitBtn.onclick = () => {
    fruits.push(new IceOption("Nouveau fruit", 0, true));
    afficherFruits();
};

// ----------------------------
// SIROPS
// ----------------------------
function afficherSirops() {
    siropEditor.innerHTML = "";
    sirops.forEach((s, i) => {
        siropEditor.innerHTML += `
        <div class="item ${s.active ? "" : "inactive"}">
            <span class="icon">🥤</span>
            <input value="${s.name}" placeholder="Sirop"
                onchange="sirops[${i}].name = this.value">
            <input type="number" step="0.01" value="${s.price}"
                onchange="sirops[${i}].price = parseFloat(this.value) || 0">
            <label>
                <input type="checkbox" ${s.active ? "checked" : ""} onchange="toggleSirop(${i})">
                Disponible
            </label>
            <button onclick="supprimerSirop(${i})">Supprimer</button>
        </div>`;
    });
}

function toggleSirop(i) {
    sirops[i].active = !sirops[i].active;
    afficherSirops();
}

function supprimerSirop(i) {
    sirops.splice(i, 1);
    afficherSirops();
}

addSiropBtn.onclick = () => {
    sirops.push(new IceOption("Nouveau sirop", 0, true));
    afficherSirops();
};

// ----------------------------
// TYPES DE GLACES (prix de base)
// ----------------------------
function afficherTypes() {
    typeEditor.innerHTML = "";
    typePrices.forEach((t, i) => {
        typeEditor.innerHTML += `
        <div class="item">
            <span class="icon">🍨</span>
            <strong style="min-width:120px; display:inline-block;">${t.label}</strong>
            <label>
                Prix de base :
                <input type="number" step="0.01" value="${t.basePrice}"
                    onchange="typePrices[${i}].basePrice = parseFloat(this.value) || 0">
            </label>
        </div>`;
    });
}

// =====================================================
// SAUVEGARDE — avec nettoyage automatique
// =====================================================
/* ------------ SAUVEGARDE AVEC VÉRIFICATION ------------ */
/* ------------ SAUVEGARDE AVEC RÉTABLISSEMENT DES LISTES VIDES ------------ */
if (saveMenuBtn) {
    saveMenuBtn.onclick = () => {

        let restored = [];

        // Vérifier chaque catégorie et restaurer si vide
        if (menu.length === 0) {
            menu = structuredClone(defaultMenu);
            restored.push("Menu (best-sellers)");
        }

        if (flavors.length === 0) {
            flavors = structuredClone(defaultFlavors);
            restored.push("Parfums");
        }

        if (toppings.length === 0) {
            toppings = structuredClone(defaultToppings);
            restored.push("Toppings");
        }

        if (fruits.length === 0) {
            fruits = structuredClone(defaultFruits);
            restored.push("Fruits");
        }

        if (sirops.length === 0) {
            sirops = structuredClone(defaultSirops);
            restored.push("Sirops");
        }

        if (typePrices.length === 0) {
            typePrices = structuredClone(defaultTypePrices);
            restored.push("Types de glaces (prix de base)");
        }

        // Si une restauration a eu lieu
        if (restored.length > 0) {
            alert(
                "Certaines catégories étaient vides et ont été restaurées automatiquement :\n\n" +
                restored.map(r => "• " + r).join("\n")
            );

            // Réafficher après restauration
            afficherMenu();
            afficherParfums();
            afficherToppings();
            afficherFruits();
            afficherSirops();
            afficherTypes();
        }

        // Sauvegarde finale
        DataStore.saveMenu(menu);
        DataStore.saveFlavors(flavors);
        DataStore.saveToppings(toppings);
        DataStore.saveFruits(fruits);
        DataStore.saveSirops(sirops);
        DataStore.saveTypePrices(typePrices);

        alert("Modifications sauvegardées !");
    };
}



// ----------------------------
// Retour accueil
// ----------------------------
goHomeBtn.onclick = () => {
    window.location.href = "index.html";
};

// ----------------------------
// Initialisation
// ----------------------------
afficherMenu();
afficherParfums();
afficherToppings();
afficherFruits();
afficherSirops();
afficherTypes();
