// =====================================================
// models.js — Classes principales + DataStore
// =====================================================


// -----------------------------------------------------
// Classe MenuItem (best-sellers)
// -----------------------------------------------------
class MenuItem {
    constructor(name, price, desc) {
        this.name = name;
        this.price = price;
        this.desc = desc;
    }

    static fromJSON(o) {
        return new MenuItem(
            o.nom || o.name || "",
            parseFloat(o.prix ?? o.price ?? 0),
            o.desc || o.description || ""
        );
    }

    toJSON() {
        return {
            nom: this.name,
            prix: this.price,
            desc: this.desc
        };
    }
}


// -----------------------------------------------------
// Classe IceOption (parfum, topping, fruit, sirop)
// -----------------------------------------------------
class IceOption {
    constructor(name, price = 0, active = true) {
        this.name = name;
        this.price = price;
        this.active = active;
    }

    static fromJSON(o) {
        return new IceOption(
            o.nom || o.name || "",
            parseFloat(o.prix ?? o.price ?? 0),
            o.actif ?? o.active ?? true
        );
    }

    toJSON() {
        return {
            nom: this.name,
            prix: this.price,
            actif: this.active
        };
    }
}


// -----------------------------------------------------
// TypePrice (prix de base des types de glaces)
// -----------------------------------------------------
class TypePrice {
    constructor(id, label, basePrice = 0) {
        this.id = id;
        this.label = label;
        this.basePrice = basePrice;
    }

    static fromJSON(o) {
        return new TypePrice(
            o.id,
            o.label || o.nom || "",
            parseFloat(o.basePrice ?? o.prixBase ?? 0)
        );
    }

    toJSON() {
        return {
            id: this.id,
            label: this.label,
            basePrice: this.basePrice
        };
    }
}


// -----------------------------------------------------
// CartItem (élément du panier)
// -----------------------------------------------------
class CartItem {
    constructor(type, form, flavors = [], toppings = [], fruits = [], sirops = [], price = 0) {
        this.type = type;
        this.form = form;
        this.flavors = flavors;
        this.toppings = toppings;
        this.fruits = fruits;
        this.sirops = sirops;
        this.price = price;
    }

    static fromJSON(o) {
        return new CartItem(
            o.type,
            o.form || o.forme || "",
            o.flavors || o.parfums || [],
            o.toppings || [],
            o.fruits || [],
            o.sirops || [],
            parseFloat(o.price ?? o.prix ?? 0)
        );
    }

    toJSON() {
        return {
            type: this.type,
            forme: this.form,
            flavors: this.flavors,
            toppings: this.toppings,
            fruits: this.fruits,
            sirops: this.sirops,
            price: this.price
        };
    }
}


// -----------------------------------------------------
// Cart (panier complet)
// -----------------------------------------------------
class Cart {
    constructor(items = []) {
        this.items = items;
    }

    static load() {
        const raw = JSON.parse(localStorage.getItem("cartData"));
        if (!Array.isArray(raw)) return new Cart([]);
        return new Cart(raw.map(CartItem.fromJSON));
    }

    save() {
        localStorage.setItem("cartData", JSON.stringify(this.items));
    }

    add(item) {
        this.items.push(item);
        this.save();
    }

    remove(index) {
        this.items.splice(index, 1);
        this.save();
    }

    total() {
        return this.items.reduce((sum, it) => sum + (it.price || 0), 0);
    }
}


// -----------------------------------------------------
// DataStore — gestion localStorage
// Avec correction :
//  → liste vide = choix volontaire
//  → valeurs par défaut seulement si aucune donnée
// -----------------------------------------------------
class DataStore {

    // ----------- Menu Best-Sellers ----------- //
    static loadMenu(defaultMenu = []) {
        const raw = JSON.parse(localStorage.getItem("menuData"));
        if (!Array.isArray(raw)) return defaultMenu; // jamais sauvegardé → defaults
        return raw.map(MenuItem.fromJSON); // même [] est valide
    }

    static saveMenu(menu) {
        localStorage.setItem("menuData", JSON.stringify(menu));
    }


    // ----------- Système générique pour Options (parfums, toppings, fruits, sirops) ----------- //
    static loadOptions(key, defaultOptions = []) {
        const raw = JSON.parse(localStorage.getItem(key));

        if (!Array.isArray(raw)) {
            // Aucune donnée existante → on retourne les defaults
            return defaultOptions;
        }

        // Même une liste vide [] est valide
        return raw.map(IceOption.fromJSON);
    }

    static saveOptions(key, list) {
        localStorage.setItem(key, JSON.stringify(list));
    }


    // Parfums
    static loadFlavors(defaultFlavors = []) {
        return this.loadOptions("flavorData", defaultFlavors);
    }
    static saveFlavors(list) {
        this.saveOptions("flavorData", list);
    }

    // Toppings
    static loadToppings(defaultToppings = []) {
        return this.loadOptions("toppingData", defaultToppings);
    }
    static saveToppings(list) {
        this.saveOptions("toppingData", list);
    }

    // Fruits
    static loadFruits(defaultFruits = []) {
        return this.loadOptions("fruitData", defaultFruits);
    }
    static saveFruits(list) {
        this.saveOptions("fruitData", list);
    }

    // Sirops
    static loadSirops(defaultSirops = []) {
        return this.loadOptions("siropData", defaultSirops);
    }
    static saveSirops(list) {
        this.saveOptions("siropData", list);
    }


    // ----------- Prix des types (Cône, Pot, Italienne, Rolls…) ----------- //
    static loadTypePrices(defaultTypePrices = []) {
        const raw = JSON.parse(localStorage.getItem("typePriceData"));

        if (!Array.isArray(raw)) {
            return defaultTypePrices; // première utilisation
        }

        return raw.map(TypePrice.fromJSON); // [] reste vide
    }

    static saveTypePrices(list) {
        localStorage.setItem("typePriceData", JSON.stringify(list));
    }
}

