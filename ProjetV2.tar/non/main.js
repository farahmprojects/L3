// =========================================================
// main.js — Nettoyé, indenté et optimisé
// =========================================================

// ---------------------------------------------------------
// Données par défaut du menu
// ---------------------------------------------------------
const defaultMenu = [
    new MenuItem("Cône de Vanille", 3.50, "Une crème classique servie en cône glace vanille"),
    new MenuItem("Boules de Chocolat", 2.50, "Une boule rafraîchissante de chocolat intense"),
    new MenuItem("Glace Italienne Fraise", 3.00, "Une glace italienne fraîche à la fraise"),
    new MenuItem("Crème glacée artisanale Noix de Coco", 4.00, "Une crème glacée artisanale à la noix de coco"),
    new MenuItem("Rolls Mangue Passion", 4.50, "Rouleaux glacés aux saveurs de mangue et passion")
];

// ---------------------------------------------------------
// Chargement du menu via DataStore
// ---------------------------------------------------------
const menu = DataStore.loadMenu(defaultMenu);

// ---------------------------------------------------------
// Affichage des best-sellers sur la page d’accueil
// ---------------------------------------------------------
const zone = document.getElementById("menu-output");

if (zone) {
    zone.innerHTML = "";

    menu.forEach(item => {
        const div = document.createElement("div");
        div.className = "menu-item";

        div.innerHTML = `
            <h3>${item.name}</h3>
            <p>${item.desc}</p>
            <span>${item.price.toFixed(2)} €</span>
        `;

        zone.appendChild(div);
    });
}

// ---------------------------------------------------------
// Accès au panneau admin via lien caché + mot de passe
// ---------------------------------------------------------
const adminLink = document.getElementById("admin-hidden-link");

if (adminLink) {
    adminLink.addEventListener("click", () => {
        const password = prompt("Mot de passe requis :");

        if (password === "admin123") {
            window.location.href = "admin.html";
        } else {
            alert("Mot de passe incorrect.");
        }
    });
}
