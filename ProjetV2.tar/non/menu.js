// =========================================================
// menu.js — VERSION NETTOYÉE, INDENTÉE ET OPTIMISÉE
// =========================================================

// ---------------------------------------------------------
// Formatage d’un prix
// ---------------------------------------------------------
function formatPrice(num) {
    return num.toFixed(2) + " €";
}

// ---------------------------------------------------------
// Chargement des options depuis DataStore (avec défauts)
// ---------------------------------------------------------
const defaultFlavors = [
    new IceOption("Vanille", 0.50, true),
    new IceOption("Chocolat", 0.50, true),
    new IceOption("Fraise", 0.50, true),
    new IceOption("Pistache", 0.70, true),
    new IceOption("Mangue", 0.70, true)
];

const defaultToppings = [
    new IceOption("Chantilly", 0.50, true),
    new IceOption("Caramel", 0.60, true),
    new IceOption("Pépites de chocolat", 0.70, true),
    new IceOption("Oréo", 0.80, true),
    new IceOption("Amandes", 0.70, true)
];

const defaultFruits = [
    new IceOption("Banane", 0.80, true),
    new IceOption("Fraise", 0.80, true),
    new IceOption("Mangue", 0.90, true),
    new IceOption("Kiwi", 0.90, true)
];

const defaultSirops = [
    new IceOption("Caramel", 0.60, true),
    new IceOption("Chocolat", 0.60, true),
    new IceOption("Fraise", 0.60, true),
    new IceOption("Fruit de la passion", 0.70, true)
];

const defaultTypePrices = [
    new TypePrice("Cône", "Cône", 3.00),
    new TypePrice("Pot", "Pot", 3.00),
    new TypePrice("Italienne", "Glace italienne", 3.00),
    new TypePrice("Rolls", "Glace Rolls", 4.50)
];

// Chargement final
const flavors     = DataStore.loadFlavors(defaultFlavors);
const toppings    = DataStore.loadToppings(defaultToppings);
const fruits      = DataStore.loadFruits(defaultFruits);
const sirops      = DataStore.loadSirops(defaultSirops);
const typePrices  = DataStore.loadTypePrices(defaultTypePrices);

let cart = Cart.load();

// ---------------------------------------------------------
// Récupère le prix de base d’un type (Cône, Pot, etc.)
// ---------------------------------------------------------
function getTypeBasePrice(type) {
    const found = typePrices.find(t => t.id === type);
    return found ? found.basePrice : 0;
}

// ---------------------------------------------------------
// Mise à jour temps réel du prix dans le pop-up
// ---------------------------------------------------------
function updatePopupPrice(type) {
    let price = getTypeBasePrice(type);

    // Boules pour Cône & Pot
    if (type === "Cône" || type === "Pot") {
        const sel = document.getElementById("boules-count");
        const boules = sel ? parseInt(sel.value) : 1;
        if (boules > 1) price += (boules - 1) * 1.00;
    }

    // Parfums / toppings
    document.querySelectorAll(".parfum-choice:checked").forEach(cb =>
        price += parseFloat(cb.dataset.price)
    );

    document.querySelectorAll(".topping-choice:checked").forEach(cb =>
        price += parseFloat(cb.dataset.price)
    );

    // Rolls : fruit + sirop
    const fruitSel = document.querySelector("input[name='fruit-rolls']:checked");
    const siropSel = document.querySelector("input[name='sirop-rolls']:checked");

    if (fruitSel) price += parseFloat(fruitSel.dataset.price);
    if (siropSel) price += parseFloat(siropSel.dataset.price);

    // Affichage
    document.getElementById("popup-price").textContent =
        "Total : " + formatPrice(price);

    return price;
}

// =========================================================
// Ouverture du pop-up pour personnaliser une glace
// =========================================================
function addToCart(type) {
    const popup = document.getElementById("custom-popup");
    const form  = document.getElementById("form-container");

    document.getElementById("popup-title").innerText = type;
    form.innerHTML = "";

    // Sélecteur de boules pour Cône & Pot
    if (type === "Cône" || type === "Pot") {
        form.innerHTML += `
            <div class="choice-group">
                <h3>Nombre de boules :</h3>
                <select id="boules-count">
                    <option value="1">1 boule</option>
                    <option value="2">2 boules</option>
                    <option value="3">3 boules</option>
                </select>
            </div>`;
    }

    // -----------------------------------------------------
    // CAS SPÉCIAL : ROLLS
    // -----------------------------------------------------
    if (type === "Rolls") {
        
        // Parfums (1 max)
        form.innerHTML += `<div class="choice-group"><h3>Parfum (1 max) :</h3>`;
        flavors.filter(f => f.active).forEach(f => {
            form.innerHTML += `
                <label>
                    <input type="radio" name="parfum-rolls" value="${f.name}" data-price="${f.price}">
                    ${f.name} (+${formatPrice(f.price)})
                </label>`;
        });
        form.innerHTML += `</div>`;

        // Fruit
        form.innerHTML += `<div class="choice-group"><h3>Fruit (1 max) :</h3>`;
        fruits.filter(fr => fr.active).forEach(fr => {
            form.innerHTML += `
                <label>
                    <input type="radio" name="fruit-rolls" value="${fr.name}" data-price="${fr.price}">
                    ${fr.name} (+${formatPrice(fr.price)})
                </label>`;
        });
        form.innerHTML += `</div>`;

        // Sirop
        form.innerHTML += `<div class="choice-group"><h3>Sirop (1 max) :</h3>`;
        sirops.filter(s => s.active).forEach(s => {
            form.innerHTML += `
                <label>
                    <input type="radio" name="sirop-rolls" value="${s.name}" data-price="${s.price}">
                    ${s.name} (+${formatPrice(s.price)})
                </label>`;
        });
        form.innerHTML += `</div>`;

        // Toppings
        form.innerHTML += `<div class="choice-group"><h3>Toppings :</h3>`;
        toppings.filter(t => t.active).forEach(t => {
            form.innerHTML += `
                <label>
                    <input type="checkbox" class="topping-choice" value="${t.name}" data-price="${t.price}">
                    ${t.name} (+${formatPrice(t.price)})
                </label>`;
        });
        form.innerHTML += `</div>`;

    } else {

        // -----------------------------------------------------
        // AUTRES TYPES : parfums + toppings
        // -----------------------------------------------------
        form.innerHTML += `<div class="choice-group"><h3>Parfums :</h3>`;
        flavors.forEach(f => {
            const disabled = f.active ? "" : "disabled";
            const style = f.active ? "" : "style='opacity:0.5;'";
            form.innerHTML += `
                <label ${style}>
                    <input type="checkbox" class="parfum-choice"
                        value="${f.name}" ${disabled} data-price="${f.price}">
                    ${f.name} (+${formatPrice(f.price)})
                </label>`;
        });
        form.innerHTML += `</div>`;

        form.innerHTML += `<div class="choice-group"><h3>Toppings :</h3>`;
        toppings.forEach(t => {
            const disabled = t.active ? "" : "disabled";
            const style = t.active ? "" : "style='opacity:0.5;'";
            form.innerHTML += `
                <label ${style}>
                    <input type="checkbox" class="topping-choice"
                        value="${t.name}" ${disabled} data-price="${t.price}">
                    ${t.name} (+${formatPrice(t.price)})
                </label>`;
        });
        form.innerHTML += `</div>`;

        setupFlavorLimits(type);
    }

    // Bouton de validation
    document.getElementById("confirm-choice").onclick =
        () => confirmChoice(type);

    popup.style.display = "flex";

    // Attache des events pour actualiser le prix
    setTimeout(() => {
        document.querySelectorAll("#form-container input").forEach(el =>
            el.addEventListener("change", () => updatePopupPrice(type))
        );
        const boulesSel = document.getElementById("boules-count");
        if (boulesSel)
            boulesSel.addEventListener("change", () => updatePopupPrice(type));

        updatePopupPrice(type);
    }, 50);
}

// ---------------------------------------------------------
// Limites automatiques de parfums selon la glace
// ---------------------------------------------------------
function setupFlavorLimits(type) {
    const checkboxes = document.querySelectorAll(".parfum-choice");
    if (!checkboxes.length) return;

    checkboxes.forEach(cb => {
        cb.addEventListener("change", () => {

            const checked = document.querySelectorAll(".parfum-choice:checked").length;

            // Italienne → 2 parfums max
            if (type === "Italienne" && checked > 2) {
                cb.checked = false;
                alert("Maximum 2 goûts pour une glace italienne.");
                return;
            }

            // Cône / Pot → boules = goûts max
            if (type === "Cône" || type === "Pot") {
                const boules = parseInt(document.getElementById("boules-count").value);
                if (checked > boules) {
                    cb.checked = false;
                    alert(`Vous avez ${boules} boule(s) : vous ne pouvez choisir que ${boules} parfum(s).`);
                }
            }
        });
    });
}

// =========================================================
// Validation et ajout au panier
// =========================================================
function confirmChoice(type) {

    // -------------------- ROLLS --------------------
    if (type === "Rolls") {
        const parf = document.querySelector("input[name='parfum-rolls']:checked");
        const fruit = document.querySelector("input[name='fruit-rolls']:checked");
        const sirop = document.querySelector("input[name='sirop-rolls']:checked");

        if (!parf)  return alert("Choisissez un parfum.");
        if (!fruit) return alert("Choisissez un fruit.");
        if (!sirop) return alert("Choisissez un sirop.");

        const toppingNames = [...document.querySelectorAll(".topping-choice:checked")]
            .map(t => t.value);

        const price = updatePopupPrice(type);

        const item = new CartItem(
            "Rolls",
            "Rolls",
            [parf.value],
            toppingNames,
            [fruit.value],
            [sirop.value],
            price
        );

        cart.add(item);
        closePopup();
        renderCart();
        return;
    }

    // ----------------- AUTRES TYPES -----------------
    const flavorEls = [...document.querySelectorAll(".parfum-choice:checked")];
    if (!flavorEls.length) return alert("Choisissez au moins un parfum.");

    const toppingEls = [...document.querySelectorAll(".topping-choice:checked")];

    const flavorNames = flavorEls.map(x => x.value);
    const toppingNames = toppingEls.map(x => x.value);

    let form = "Standard";

    if (type === "Cône" || type === "Pot") {
        const boules = parseInt(document.getElementById("boules-count").value);
        form = `${boules} boules`;
    }
    if (type === "Italienne") {
        form = "Italienne";
    }

    const price = updatePopupPrice(type);

    const item = new CartItem(
        type,
        form,
        flavorNames,
        toppingNames,
        [],
        [],
        price
    );

    cart.add(item);
    closePopup();
    renderCart();
}

// =========================================================
// Affichage du panier
// =========================================================
function closePopup() {
    document.getElementById("custom-popup").style.display = "none";
}

function renderCart() {
    const zone  = document.getElementById("cart-items");
    const total = document.getElementById("cart-total");

    zone.innerHTML = "";

    cart.items.forEach((it, i) => {

        let details = "";
        if (it.flavors.length)
            details += `<div>🍦 <strong>Parfums :</strong> ${it.flavors.join(", ")}</div>`;
        if (it.fruits.length)
            details += `<div>🍓 <strong>Fruits :</strong> ${it.fruits.join(", ")}</div>`;
        if (it.sirops.length)
            details += `<div>🥤 <strong>Sirops :</strong> ${it.sirops.join(", ")}</div>`;
        if (it.toppings.length)
            details += `<div>🍫 <strong>Toppings :</strong> ${it.toppings.join(", ")}</div>`;

        zone.innerHTML += `
            <div class="cart-item">
                <b>${it.type}</b>
                <div class="cart-form">${it.form}</div>
                <div class="cart-details">${details}</div>
                <div class="price-tag">${formatPrice(it.price)}</div>
                <button class="cart-remove-btn" onclick="removeFromCart(${i})">Retirer</button>
            </div>`;
    });

    total.textContent = formatPrice(cart.total());
}

function removeFromCart(i) {
    cart.remove(i);
    renderCart();
}

function goToCart() {
    window.location.href = "panier.html";
}

renderCart();
