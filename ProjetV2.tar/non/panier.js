// ====================================================
// panier.js — Page panier complète
// ====================================================

let cart = Cart.load();

const listZone = document.getElementById("cart-list");
const totalZone = document.getElementById("cart-total");

function formatPrice(num) {
    return num.toFixed(2) + " €";
}

// ----------------------------
// Affichage du panier
// ----------------------------
function renderFullCart() {

    listZone.innerHTML = "";

    if (cart.items.length === 0) {
        listZone.innerHTML = `<p>Votre panier est vide.</p>`;
        totalZone.textContent = "0.00 €";
        return;
    }

    cart.items.forEach((item, i) => {

        let details = "";

        if (item.flavors.length) details += `<div>🍦 <strong>Parfums :</strong> ${item.flavors.join(", ")}</div>`;
        if (item.fruits.length)  details += `<div>🍓 <strong>Fruits :</strong> ${item.fruits.join(", ")}</div>`;
        if (item.sirops.length)  details += `<div>🥤 <strong>Sirops :</strong> ${item.sirops.join(", ")}</div>`;
        if (item.toppings.length) details += `<div>🍫 <strong>Toppings :</strong> ${item.toppings.join(", ")}</div>`;
        if (details === "") details = "<div>Aucun supplément.</div>";

        listZone.innerHTML += `
            <div class="cart-item">
                <b>${item.type}</b> — <i>${item.form}</i>

                <div class="cart-details">${details}</div>

                <div class="price-tag">${formatPrice(item.price)}</div>

                <button class="remove-btn" onclick="removeItem(${i})">Supprimer</button>
            </div>
        `;
    });

    totalZone.textContent = formatPrice(cart.total());
}

// ----------------------------
// Suppression d’un article
// ----------------------------
function removeItem(i) {
    cart.remove(i);
    renderFullCart();
}

// Initialisation
renderFullCart();
