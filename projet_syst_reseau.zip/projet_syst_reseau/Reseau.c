#include "reseau.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include "Structure.h"
#include <arpa/inet.h>
#include <unistd.h>

#define BACKLOG 10 // file d'attente TCP

/* ====================== CREATION ET INITIALISATION DE SOCKET ====================== */

/**
 * Crée une socket serveur TCP sur le port fourni.
 * @param PORT Port sur lequel écouter
 * @return Socket serveur (fd >= 0)
 */
int creer_socket_serveur(uint16_t PORT) {
    int sockfd;
    struct sockaddr_in serv_addr; 
    int opt = 1;

    // Création de la socket TCP IPv4
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) { 
        perror("socket"); 
        exit(EXIT_FAILURE); 
    }

    // Permet de réutiliser le port si nécessaire
    if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) == -1) {
        perror("setsockopt");
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    // Initialisation de l'adresse serveur
    memset(&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY; // toutes les interfaces locales
    serv_addr.sin_port = htons(PORT);

    // Association de la socket à l'adresse et au port
    if (bind(sockfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) {
        perror("bind");
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    // Mise en écoute de la socket avec BACKLOG connections max
    if (listen(sockfd, BACKLOG) < 0) {
        perror("listen");
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    printf("Serveur en attente de joueurs…\n");
    return sockfd;
}

/* ====================== GESTION DES CONNEXIONS ====================== */

/**
 * Attend nb_joueurs connexions et les stocke dans clients[]
 * @param sockfd Socket serveur
 * @param nb_joueurs Nombre de joueurs attendus
 * @param clients Tableau des sockets clients
 * @return 0 si succès, -1 si erreur
 */
int attendre_connexion_joueurs(int sockfd, int nb_joueurs, int clients[]) {
    if (sockfd < 0 || nb_joueurs <= 0 || clients == NULL) return -1;

    struct sockaddr_in cli_addr; 
    socklen_t clilen = sizeof(cli_addr);

    for (int i = 0; i < nb_joueurs; ++i) {
        // Acceptation d'un client (bloquant)
        int client_fd = accept(sockfd, (struct sockaddr*)&cli_addr, &clilen);
        if (client_fd < 0) {
            perror("Erreur accept");
            return -1;
        }
        clients[i] = client_fd;

        printf("Joueur %d connecté depuis %s:%d (fd=%d)\n",
               i + 1,
               inet_ntoa(cli_addr.sin_addr),
               ntohs(cli_addr.sin_port),
               client_fd);
    }
    return 0;
}

/**
 * Connexion côté client à un serveur
 * @param ip_serveur Adresse IP du serveur
 * @param port Port du serveur
 * @return Socket connecté ou -1 en cas d'erreur
 */
int connexion_serveur(const char *ip_serveur, uint16_t port) {
    if (ip_serveur == NULL) return -1;

    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("Erreur socket");
        return -1;
    }

    struct sockaddr_in serv_addr; 
    memset(&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(port);

    // Conversion IP en binaire
    if (inet_pton(AF_INET, ip_serveur, &serv_addr.sin_addr) != 1) {
        perror("Adresse IP non valide");
        close(sockfd);
        return -1;
    }

    // Connexion TCP
    if (connect(sockfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) {
        perror("Erreur connexion serveur");
        close(sockfd);
        return -1;
    }

    printf("Connecté au serveur %s:%u (fd=%d)\n", ip_serveur, port, sockfd);
    return sockfd;
}

/* ====================== ENVOI ET RÉCEPTION DE MESSAGES ====================== */

/**
 * Envoie un message complet sur le socket
 * @param sockfd Socket du destinataire
 * @param message Buffer contenant le message
 * @param taille Taille du buffer (0 = calcul via strlen)
 * @return Nombre d'octets envoyés ou -1
 */
ssize_t envoyer_message(int sockfd, const char *message, size_t taille) {
    if (sockfd < 0 || message == NULL) return -1;
    if (taille == 0) taille = strlen(message);

    ssize_t total_sent = 0;
    while (total_sent < (ssize_t)taille) {
        ssize_t n = send(sockfd, message + total_sent, taille - total_sent, 0);
        if (n < 0) {
            if (errno == EINTR) continue; // interruption signal
            perror("Erreur d'envoi");
            return -1;
        }
        total_sent += n;
    }
    printf("DEBUG: message envoyé (%zd octets) sur fd=%d\n", total_sent, sockfd);
    return total_sent;
}

/**
 * Reçoit un message depuis le socket
 * @param sockfd Socket source
 * @param buffer Buffer pour stocker le message
 * @param taille Taille du buffer
 * @return Nombre d'octets reçus, 0 si fermeture, -1 si erreur
 */
ssize_t recevoir_message(int sockfd, char *buffer, size_t taille) {
    if (sockfd < 0 || buffer == NULL || taille == 0) return -1;
    memset(buffer, 0, taille); // éviter les anciens messages

    ssize_t n = recv(sockfd, buffer, taille - 1, 0);
    if (n < 0) {
        if (errno == EINTR) return recevoir_message(sockfd, buffer, taille);
        perror("Erreur lors de la réception du message");
        return -1;
    }
    if (n == 0) return 0; // socket fermé

    buffer[n] = '\0';
    printf("[DEBUG RESEAU] Message reçu (fd=%d) : %s\n", sockfd, buffer);
    return n;
}

/* ====================== ENVOI À TOUS LES JOUEURS ====================== */

/**
 * Envoie un message à tous sauf le joueur avec id_exclu
 */
void envoyer_a_tous_sauf(const Joueur liste[], int nb, int id_exclu, const char *msg) {
    if (liste == NULL || msg == NULL) return;
    for (int i = 0; i < nb; ++i) {
        if (liste[i].id == id_exclu) continue;
        if (liste[i].sock >= 0) {
            envoyer_message(liste[i].sock, msg, 0);
        }
    }
}

/**
 * Envoie un message à tous les joueurs
 */
void envoyer_messages_a_tous(const Joueur liste[], int nb, const char *msg) {
    if (liste == NULL || msg == NULL) return;
    for (int i = 0; i < nb; ++i) {
        if (liste[i].sock >= 0) {
            envoyer_message(liste[i].sock, msg, 0);
        }
    }
}

/* ====================== DEMANDES AUX JOUEURS ====================== */

/**
 * Demande au joueur de choisir une ligne
 * @return indice de ligne ou -1 si erreur
 */
int demander_ligne_res(int sock, Joueur *j) {
    if (sock < 0 || j == NULL) return -1;
    char buff[TAILLE_BUF];
    ssize_t n = recevoir_message(sock, buff, sizeof(buff));
    if (n <= 0) {
        fprintf(stderr, "Erreur/reception (ligne) joueur %d (n=%zd)\n", j->id, n);
        return -1;
    }

    int valeur = -1;
    if (sscanf(buff, "LIGNE %d", &valeur) != 1) {
        fprintf(stderr, "Message LIGNE mal formée reçu: %s\n", buff);
        return -1;
    }
    return valeur;
}

/**
 * Demande au joueur de choisir une carte
 * @return indice carte ou -1 si erreur
 */
int demander_carte_res(int sock, Joueur *j) {
    if (sock < 0 || j == NULL) return -1;
    char buff[TAILLE_BUF];
    ssize_t n = recevoir_message(sock, buff, sizeof(buff));
    if (n <= 0) {
        fprintf(stderr, "Erreur/reception (carte) joueur %d (n=%zd)\n", j->id, n);
        return -1;
    }

    int valeur = -1;
    if (sscanf(buff, "CARTE %d", &valeur) != 1) {
        fprintf(stderr, "Message CARTE mal formée reçu: %s\n", buff);
        return -1;
    }
    return valeur;
}
