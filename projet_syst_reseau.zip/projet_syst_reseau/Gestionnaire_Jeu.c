#include <stdio.h>     
#include <stdlib.h>     
#include <string.h>     
#include <time.h>       
#include <sys/types.h>  


// En-têtes de ton projet (structures, constantes, fonctions réseau...)
#include "Gestionnaire_Jeu.h" // Contient probablement la logique globale du jeu / constantes (NB_manche, etc.)
#include "Structure.h"         // Contient les struct Carte, Joueur, enums EtatCarte, ModeJeu...
#include "Reseau.h"            // Contient envoyer_message, envoyer_messages_a_tous, demander_carte_res, etc.

int nb_cartes_par_rangee[4] = {0}; // Compteur : nb de cartes ACTUELLES dans chaque rangée (4 rangées)
int nb_cartes_par_col[6] = {0};    // Compteur par colonne (6 colonnes max) - (semble peu utilisé ici)
Carte plateau[4][6];               // Plateau : 4 rangées, 6 cases max chacune (cases vides num=0)
Carte carte[Nb_Carte_Totale];      // Paquet global : toutes les cartes (taille totale définie ailleurs)
int nb_joueurs = 0;                // Nombre de joueurs dans la partie (déterminé ailleurs)


// Tableau global des joueurs (taille max définie par MAX_Joueur)
Joueur Lst_joueur[MAX_Joueur];


// Mode de jeu : par défaut Joueur vs Joueur
ModeJeu mode_jeu = MODE_JVJ; // valeur par défaut



void error(char *msg) // Fonction utilitaire d’arrêt brutal : affiche l’erreur système et quitte
{
 perror(msg);  // Affiche msg + description errno (ex: "fopen: Permission denied")
 exit(1);      // Termine immédiatement le programme avec code d'erreur 1
}

// Calcule des bœufs selon les règles
int calculer_boeufs(Carte *c) {        // Prend un pointeur sur une carte (on modifie c->boeufs)
 int v = c->numero;                    // v = numéro de la carte (utilisé pour décider le nb de boeufs)

 if (v == 55)                          // Cas spécial : carte 55 -> 7 têtes de bœufs
 c->boeufs = 7;
 else if (v % 11 == 0)                 // Multiple de 11 (11,22,33...) -> 5 boeufs
 c->boeufs = 5;
 else if (v % 10 == 0)                 // Multiple de 10 (10,20,30...) -> 3 boeufs
 c->boeufs = 3;
 else if (v % 5 == 0)                  // Multiple de 5 (5,15,25...) -> 2 boeufs
 c->boeufs = 2;
 else                                  // Sinon -> 1 boeuf
 c->boeufs = 1;

 //printf("Attribution : carte %d → %d boeufs\n", c->valeur, c->boeufs);
 return c->boeufs;                     // Retourne le nombre de boeufs attribué
 }



void Initialisation_Plateaux_vide()     // Met le plateau dans un état "vide" (remise à zéro)
{
 for (int i = 0; i < 4; i++)           // Parcours des 4 rangées
 {
 nb_cartes_par_rangee[i] = 0;          // Aucune carte dans la rangée i
 for (int j = 0; j < 6; j++)           // Parcours des 6 colonnes / positions possibles
 {
 plateau[i][j].numero = 0;             // Case vide => numero=0
 plateau[i][j].boeufs = 0;             // Et boeufs=0 (cohérence affichage)
 }
 }
}
void Afficher_Plateaux()                // Affiche le plateau côté serveur (debug/console)
{
 for (int i = 0; i < 4; ++i)           // Pour chaque rangée
 {
 for (int j = 0;j < 6; j++)            // Pour chaque colonne/position
 {
 printf("%d (%d B) ",plateau[i][j].numero,plateau[i][j].boeufs); // Affiche numéro + boeufs
 }
 printf(" \n");                         // Retour à la ligne après chaque rangée
 }

}

void Afficher_score()                   // Affiche les scores de tous les joueurs
{
 for (int i = 0; i < nb_joueurs; i++)   // Parcours des joueurs actifs
 {
 printf("le score du joueur %d est de : %d \n",Lst_joueur[i].id,Lst_joueur[i].score); // id + score
 }
}


// Tire une carte non encore utilisée
int tirer_carte_non_utilisee() {        // Choisit une carte encore en ETAT_PIOCHE et la passe en ETAT_MAIN
 int indice;                            // Indice dans le tableau global carte[]
 do {                                   // Boucle jusqu’à tomber sur une carte disponible
 indice = rand() % Nb_Carte_Totale+1;   // Tire un nombre pseudo-aléatoire (attention: +1 => plage différente)
 } while (carte[indice].etat != ETAT_PIOCHE); // Tant que la carte n’est pas dans la pioche, on recommence
 carte[indice].etat = ETAT_MAIN;        // Marque la carte comme étant maintenant dans une main
 return indice;                         // Retourne l’indice de la carte tirée
}

/**
 *
 * @param nouvel_etat Le nouvelle état de notre carte que on met en param pour la rendre donc plus utilisable
 * @return renvoie l'indice de la carte tirer
 * */
int tirer_carte_alea(EtatCarte nouvel_etat) { // Même idée : tire une carte libre, mais l’état final est paramétrable
 int indice;                                  // Indice dans tableau carte[]
 do {                                         // Répète tant que l’indice pointe une carte non disponible
 indice = rand() % Nb_Carte_Totale;           // Tire un indice dans [0..Nb_Carte_Totale-1]
 //printf("L'indice de la carte tirer en alea est : %d\n",indice);
 } while (carte[indice].etat != ETAT_PIOCHE); // On veut uniquement une carte dans la pioche
 carte[indice].etat = nouvel_etat;            // On “réserve” la carte en lui assignant son nouvel état
 return indice;                               // Retourne l’indice (pour copier carte[indice] ailleurs)
}

/**
 *
 * @param client on met donc ici la liste de nos client (2 le plus souvent)
 * on renvoie rien car il suffit juste de initialiser leurs main / id et on leurs associe un sock (le score 0)
 *
 */
void Initalisation_Joueur_V1(int client[]) {                 // Initialise tous les joueurs (version simple JVJ)
 for (int i = 0; i < nb_joueurs; i++) {                     // Boucle sur chaque joueur (0..nb_joueurs-1)
 Lst_joueur[i].id = i + 1;                                  // ID logique du joueur (commence à 1)
 Lst_joueur[i].score = 0;                                   // Score initial à 0 têtes de boeufs
 Lst_joueur[i].nb_cartes = Carte_par_Joueur;                // Nb cartes en main au début (constante globale, ex: 10)
 Lst_joueur[i].sock=client[i];                              // Associe le socket réseau correspondant à ce joueur
 for (int j = 0; j < Carte_par_Joueur; j++) {               // Pour remplir sa main (Carte_par_Joueur cartes)
 int idx = tirer_carte_alea(ETAT_MAIN);                     // Tire une carte disponible de la pioche + la marque ETAT_MAIN
 Lst_joueur[i].cartes[j] = carte[idx];                      // Copie la carte tirée dans la main du joueur
 Lst_joueur[i].cartes[j].etat = ETAT_MAIN;                  // Force l’état de la copie (cohérence côté joueur)
 }
 }
}
void Initalisation_Joueur(int client[]) {                    // Initialise les joueurs selon le mode (JVJ ou Robot vs Joueur)

 if (mode_jeu == MODE_JVJ) {                                 // Si mode Joueur vs Joueur
 for (int i = 0; i < nb_joueurs; i++)                         // Pour chaque joueur humain
 {
 Lst_joueur[i].id = i + 1;                                    // ID logique
 Lst_joueur[i].score = 0;                                      // Score initial
 Lst_joueur[i].nb_cartes = Carte_par_Joueur;                   // Taille initiale de la main
 Lst_joueur[i].sock=client[i];                                 // Socket associé (communication réseau)
 for (int j = 0; j < Carte_par_Joueur; j++) {                  // Distribution initiale de Carte_par_Joueur cartes
 int idx = tirer_carte_alea(ETAT_MAIN);                        // Tire carte et la réserve pour la main
 Lst_joueur[i].cartes[j] = carte[idx];                         // Copie dans la main
 Lst_joueur[i].cartes[j].etat = ETAT_MAIN;                     // Force état côté joueur
 }
 }
 }
 else {                                                        // Sinon : mode Robot vs Joueur (1 humain + 1 robot)
 printf("[DEBUG] mode de jeux Robot VS J \n");                 // Message debug serveur

 // on met les cartes
 // J VS ROBOT

 // Joueur humain
 Lst_joueur[0].id = 1;                                         // Joueur 1
 Lst_joueur[0].est_robot = 0;                                  // Flag : humain
 Lst_joueur[0].score = 0;                                      // Score initial
 Lst_joueur[0].nb_cartes = Carte_par_Joueur;                   // Nb cartes en main
 Lst_joueur[0].sock = client[0];                               // Socket du joueur humain

 for (int j = 0; j < Carte_par_Joueur; j++) {                  // Distribution main du joueur humain
 int idx = tirer_carte_alea(ETAT_MAIN);                        // Tire dans la pioche
 Lst_joueur[0].cartes[j] = carte[idx];                         // Copie dans la main
 Lst_joueur[0].cartes[j].etat = ETAT_MAIN;                     // Force état
 }

 // Joueur robot
 Lst_joueur[1].id = 2;                                         // Joueur 2
 Lst_joueur[1].est_robot = 1;                                  // Flag : robot / IA
 Lst_joueur[1].score = 0;                                      // Score initial
 Lst_joueur[1].nb_cartes = Carte_par_Joueur;                   // Nb cartes en main
 Lst_joueur[1].sock = -1;                                      // Pas de socket : robot local (donc pas de demande réseau)

 for (int j = 0; j < Carte_par_Joueur; j++) {                  // Distribution main du robot
 int idx = tirer_carte_alea(ETAT_MAIN);                        // Tire dans la pioche
 Lst_joueur[1].cartes[j] = carte[idx];                         // Copie
 Lst_joueur[1].cartes[j].etat = ETAT_MAIN;                     // Force état
 }
 }
}

/**
 * tout les carte de base son a un état de pioche le
 * changement d'etat est fait dans l'initialisation des joueurs
 */
void Initialisation_Carte() {                                  // Initialise le paquet global (carte[])
 for (int i = 0; i < Nb_Carte_Totale; i++) {                   // Parcours de toutes les cartes du paquet
 carte[i].numero = i + 1;                                      // Numérotation logique : 1..Nb_Carte_Totale
 calculer_boeufs(&carte[i]);                                   // Calcule et remplit carte[i].boeufs
 carte[i].etat = ETAT_PIOCHE;                                  // État initial : disponible dans la pioche
 }
}
void distribuer_cartes()
{
 for (int i = 0; i < nb_joueurs; i++) {                        // Pour chaque joueur
 Lst_joueur[i].nb_cartes = Carte_par_Joueur;                   // Réinitialise taille de la main à la valeur standard
 for (int j = 0; j < Carte_par_Joueur; j++) {                  // Pour chaque emplacement de main
 int idx = tirer_carte_alea(ETAT_MAIN);                        // Tire une carte de la pioche et la marque en main
 Lst_joueur[i].cartes[j] = carte[idx];                         // Copie la carte dans la main du joueur
 }
 }
}


/**
 * ICI on utilise pour quand le joueur doit ramasser une ligne et donc on ajoutera ce score au joueur en question
 * @param ligne La ligne que on veut calculer
 * @return renvoie donc le score total de la ligne en terme de tete de boeufs
 */
int Score_Ligne(int ligne){                                     // Calcule le total de boeufs sur une rangée donnée
 int score = 0;                                                // Accumulateur
 for (int i = 0; i < nb_cartes_par_rangee[ligne]; i++)          // On parcourt uniquement les cartes réellement posées
 {
 score += plateau[ligne][i].boeufs;                            // Ajoute les boeufs de chaque carte
 }
 return score;                                                 // Retourne le total
}

/**
 * on affiche l'ensemble des carte des joueurs en prenant en compte le nb de carte qu'il ont jouer
 */
void Afficher_carte()
{
 for (int i = 0; i < nb_joueurs; i++)                           // Parcours des joueurs
 {
 int cpt =0;                                                    // Compteur de cartes "non vides" (numero != 0)
 for (int k = 0; k < Carte_par_Joueur; k++)                     // Parcours de tous les slots de la main (taille max)
 {
 if (Lst_joueur[i].cartes[k].numero != 0)                       // Si la carte n’est pas considérée vide
 // donc si la valeur de la carte est diff de 0 on ajout au cpt le nb
 // que il doit afficher
 {
 cpt ++;                                                        // On compte cette carte comme affichable
 }
 }
 printf("les carte du joueur %d\n ",Lst_joueur[i].id);           // Affiche l’identifiant du joueur

 for (int j = 0; j < cpt; j++)                                   // Affiche seulement les cpt premières cartes
 {
 if (Lst_joueur[i].cartes[j].etat == ETAT_MAIN)                  // On affiche uniquement celles encore en main
 // es que c'est pertinant ?
 // ici on pourrai au lieu de faire un cpt juste checker l'état de la main a la prmière boubcle ?
 // TODO refaire ici cette méthode en utilisant létat des carte et non un cpt
 {
 printf("cartes : %d \n",Lst_joueur[i].cartes[j].numero);        // Affiche le numéro de carte
 }

 }
 }
}

/**
 *
 * @param cartes l'ensemble des cartes que l'on veut trier ici on trie en fonction des cartes jouer
 * @param n ici c'est le nb de joueur
 * Elle permet de ranger dans l'ordre les cartes
 */
void trier_carte(Carte cartes[], int n) {                        // Tri par sélection (selection sort) sur le champ numero
 for (int i = 0; i < n - 1; i++) {                               // Position à remplir (0..n-2)
 int min = i;                                                    // Indice du minimum courant
 for (int j = i + 1; j < n; j++) {                               // Cherche le minimum dans le reste du tableau
 if (cartes[j].numero < cartes[min].numero) {                    // Compare les numéros de cartes
 min = j;                                                        // Nouveau minimum trouvé
 }
 }
 if (min != i) {                                                 // Si le minimum n'est pas déjà à la bonne place
 Carte tmp = cartes[i];                                          // Sauvegarde
 cartes[i] = cartes[min];                                        // Échange
 cartes[min] = tmp;                                              // Fin échange
 }
 }
}



/* Utilise le plateau global : Carte plateau[4][6]; */
void Initialisation_Plateaux() {
 //printf("DEBUG: init plateau appelée\n");                       // Debug désactivé
 // 1) Vider d'abord le plateau et les compteurs
 Initialisation_Plateaux_vide();                                  // Remet nb_cartes_par_rangee[] à 0 + plateau à 0
 // 2) Tirer 4 cartes distinctes pour former les rangées initiales
 for (int i = 0; i < 4; i++) {                                    // Pour chaque rangée du plateau
 int indice = 0;                                                  // Stocke l'indice de carte tirée
 // tirer_carte_alea ou tirer_carte(ETAT_PLATEAU) : doit renvoyer un indice libre
 indice = tirer_carte_alea(ETAT_PLATEAU);                         // Tire une carte et la marque comme sur le plateau
 //indice--; // decalage sinon sur le plateau
 //printf("l'indice de la carte tirer est : %d\n",indice);
 // sécurise
 if (indice < 0 || indice >= Nb_Carte_Totale) {                   // Vérifie que l'indice est dans les bornes du paquet
 fprintf(stderr, "Erreur : indice carte invalide %d\n", indice);  // Message d'erreur
 continue;                                                        // Passe à la rangée suivante
 }
 // placer la carte sur la rangée i, position 0
 plateau[i][0] = carte[indice];                                   // Place la carte en tête de la rangée
 carte[indice].etat = ETAT_PLATEAU;                               // Force l’état (cohérence globale)
 nb_cartes_par_rangee[i] = 1;                                     // La rangée contient 1 carte
 }
 Afficher_Plateaux();                                             // Affiche le plateau (debug) après init

}

// affichage simple pour le debug
void afficher_etat_de_la_carte(Carte c) {                          // Affiche l’état interne d’une carte (numero + etat)
 printf("Carte %3d : etat = %d\n", c.numero, c.etat);              // Format aligné : numéro sur 3 chars
}

void afficher_etat_cartes() {                                      // Affiche l’état de TOUTES les cartes du paquet
 for (int i = 0; i < Nb_Carte_Totale; i++) {                       // Parcours de toutes les cartes
 printf("[i=%3d] Carte valeur=%3d : etat = %d\n",
 i,                                                                // indice dans le tableau (position mémoire)
 carte[i].numero,                                                  // numéro logique (1..Nb_Carte_Totale)
 carte[i].etat);                                                   // état (PIOCHE, MAIN, PLATEAU, JOUEE...)
 }
}
/**
 *
 * @param main_joueur la main du joueur en param on a une boucle dans la mise a jour avant pour faire l'esemble des joueurs
 * @param nb_cartes le nb de carte du joueur
 * @return renvoie la nouvelle taille de la main du joueur
 */
int mise_a_jour_carte_joueur(Carte main_joueur[], int nb_cartes) {
 // Variable qui représentera le nouveau nombre de cartes encore réellement en main (ETAT_MAIN)
 int nouvelle_taille = 0;

 // Parcours des nb_cartes cartes logiques actuellement considérées comme dans la main
 for (int i = 0; i < nb_cartes; i++) {
  // On ne garde que les cartes dont l’état est encore "dans la main"
  if (main_joueur[i].etat == ETAT_MAIN) {
   // On compacte : on recopie cette carte au début du tableau (à l’indice nouvelle_taille)
   // Puis on incrémente nouvelle_taille
   main_joueur[nouvelle_taille++] = main_joueur[i];
  }
 }

 // Une fois compacté, on "nettoie" le reste du tableau pour éviter d’avoir des anciennes valeurs résiduelles
 // (utile pour affichage, debug, envoi réseau…)
 for (int i = nouvelle_taille; i < Carte_par_Joueur; i++) {
  // Marque la carte comme "vide" / invalidée (ici numero=-1 dans ton code)
  main_joueur[i].numero = -1;
  // Boeufs à 0 car carte neutralisée
  main_joueur[i].boeufs = 0;
  // Etat mis à ETAT_JOUEE (signifie : elle ne fait plus partie de la main jouable)
  main_joueur[i].etat = ETAT_JOUEE;
 }

 // Retourne la nouvelle taille logique de la main (nombre de cartes encore ETAT_MAIN)
 return nouvelle_taille;
}


/**
 *
 * @param j Le joueur en param que on veut envoyer les cartes
 * @param msg et donc le msg que on construit avec l'ensemble des carte du joueur (qu'il possède)
 */
void convertir_carte_en_char(Joueur *j, char *msg) {
 // On commence par vider le buffer destination (chaîne vide)
 msg[0] = '\0';
 // Préfixe "MAIN" pour que le client sache interpréter le message
 strcat(msg, "MAIN\n");

 // Petit buffer temporaire pour formater une carte en texte avant de la concaténer
 char temp[32];
 // Parcourt les cartes logiques du joueur (j->nb_cartes doit être à jour)
 for (int i = 0; i < j->nb_cartes; i++) {
  // Format texte : "<numero>(<boeufs>) " pour chaque carte
  sprintf(temp, "%d(%d) ", j->cartes[i].numero, j->cartes[i].boeufs);
  // Ajoute ce morceau au message global
  strcat(msg, temp);
 }
 // Termine par un saut de ligne pour "fin de message" côté affichage/protocole
 strcat(msg, "\n");
}

/**
 *
 * @param msg on construit un msg avec l'ensemble des cartes sur le plateau
 */
void convertir_plateau_en_char(char *msg) {
 // Reset buffer : message vide au départ
 msg[0] = '\0';

 // Ajoute l’en-tête "PLATEAU" (important pour le protocole)
 strcat(msg, "PLATEAU\n"); // PAS d'espace, PAS de saut de ligne devant

 // Buffer temporaire pour une cellule du plateau (un nombre formaté)
 char temp[32];
 // Parcours des 4 rangées
 for (int i = 0; i < 4; i++) {
  // Parcours des 6 positions par rangée
  for (int j = 0; j < 6; j++) {
   // Formate le numero de la carte (sur 3 caractères, alignement), ex: " 12 "
   sprintf(temp, "%3d ", plateau[i][j].numero);
   // Concatène au message global
   strcat(msg, temp);
  }
  // Fin de rangée -> saut de ligne
  strcat(msg, "\n");
 }
}

/**
 *
 * @param LstJoueurs La liste de nos joueurs
 * @param msg le message une fois conertie (donc le score)
 */
void convertir_score_en_char(Joueur LstJoueurs [], char *msg)
{
 // Reset message
 msg[0] = '\0';
 // En-tête "SCORE" pour le protocole client/serveur
 strcat(msg, "SCORE\n");
 // Buffer temporaire pour convertir un entier score en texte
 char temp[32];
 // Parcourt les joueurs actifs
 for (int i =0; i < nb_joueurs; i++)
 {
  // Convertit le score en chaîne (sans mise en forme particulière)
  sprintf(temp, "%d", LstJoueurs[i].score); // normalement le score est bon
  // Ajoute au message
  strcat(msg, temp);
  // Ajoute un saut de ligne : 1 score par ligne
  strcat(msg, "\n");
 }
}
// robot méthodes
/**
 *
 * @param j
 * @return
 */
int robot_choisir_carte(Joueur *j)
{
 // Indice (dans j->cartes[]) de la meilleure carte trouvée
 int meilleur_indice = -1;
 // Mesure de "proximité" minimale trouvée (différence entre carte et dernière carte de rangée)
 int meilleure_proximite = 999;

 // Debug : on annonce qu’on est en train de choisir
 printf("[DEBUG] ROBOT choisit sa carte : ");
 // Pour chaque carte dans la main du robot (selon j->nb_cartes)
 for (int i = 0; i < j->nb_cartes; i++)
 {
  // Si cette carte n’est pas en main, on ignore (déjà jouée / invalidée)
  if (j->cartes[i].etat != ETAT_MAIN)
  continue;

  // Valeur/numéro de la carte candidate
  int val = j->cartes[i].numero;
  // Ligne qui serait la meilleure destination pour cette carte
  int meilleure_ligne = -1;
  // Proximité de cette carte à sa meilleure ligne
  int proximite = 999;

  // essaie de placer la carte sur les 4 rangées
  for (int l = 0; l < 4; l++)
  {
   // nb cartes actuellement sur la rangée l
   int nb = nb_cartes_par_rangee[l];
   // Si rangée vide, pas exploitable ici
   if (nb == 0) continue;

   // Dernière carte de la rangée (celle à comparer)
   int last = plateau[l][nb-1].numero;

   // Règle de placement : carte doit être STRICTEMENT supérieure à la dernière carte de la rangée
   if (val > last)
   {
    // Différence : plus elle est petite, plus on "colle" à la rangée
    int diff = val - last;
    // On garde la rangée qui minimise cette différence pour cette carte
    if (diff < proximite)
    {
     proximite = diff;
     meilleure_ligne = l;
    }
   }
  }

  // on garde la carte qui a la meilleure proximité
  // => parmi toutes les cartes candidates, on préfère celle qui s’insère au plus près d’une fin de rangée
  if (meilleure_ligne != -1 && proximite < meilleure_proximite)
  {
   meilleure_proximite = proximite;
   meilleur_indice = i;
  }
 }

 // cas où aucune carte ne peut être posée
 if (meilleur_indice == -1)
 {
  // joue la plus petite carte (stratégie de secours)
  int min_val = 999;
  for (int i = 0; i < j->nb_cartes; i++)
  {
   // On cherche la plus petite carte encore en main
   if (j->cartes[i].etat == ETAT_MAIN && j->cartes[i].numero < min_val)
   {
    min_val = j->cartes[i].numero;
    meilleur_indice = i;
   }
  }
 }
 // Debug : affiche la carte choisie
 printf("%d\n",j->cartes[meilleur_indice].numero);
 // Retourne l’indice dans la main du robot
 return meilleur_indice;
}

int robot_choisir_ligne(Joueur *j)
{
 // Ligne choisie (par défaut 0)
 int meilleure_ligne = 0;
 // Nombre minimal de boeufs trouvé jusqu’ici
 int min_boeufs = 999;

 // On évalue les 4 rangées
 for (int l = 0; l < 4; l++)
 {
  // Total boeufs sur la rangée l
  int total = 0;
  // Somme des boeufs sur toutes les cartes présentes dans cette rangée
  for (int i = 0; i < nb_cartes_par_rangee[l]; i++)
  total += plateau[l][i].boeufs;

  // On garde la rangée qui minimise le total de boeufs à ramasser
  if (total < min_boeufs)
  {
   min_boeufs = total;
   meilleure_ligne = l;
  }
 }

 // Retourne l’index de rangée (0..3)
 return meilleure_ligne;
}

int choisir_carte(Joueur *j)
{
 // Si joueur robot, on utilise l’IA locale
 if (j->est_robot)
 {
  return robot_choisir_carte(j); // IA
 }
 // Sinon, joueur humain : on demande au client via le réseau
 return demander_carte_res(j->sock, j); // sinon humain

}
int choisir_ligne(Joueur *j)
{
 // Si robot : IA
 if (j->est_robot)
 {
  return robot_choisir_ligne(j);
 }
 // Sinon humain : on demande au client la ligne choisie via le réseau
 return demander_ligne_res(j->sock, j);
}
/**
 *
 * @param joueur on a un joueur qui doit placer une carte donc on recup ce joueur
 * @param c et donc la carte en question quil joue
 * // TODO Potentiellement un changement plus tard car bug dans le code avec l'envoie d'un msg que a un seul socket
 */
void placer_carte(Joueur *joueur, Carte c)
{
 // Index de la ligne sur laquelle on va placer la carte (ou -1 si aucune ligne valide)
 int ligne_cible = -1;
 // On mémorise la meilleure "dernière carte" trouvée (la plus grande < c.numero)
 int meilleure_valeur = -1;

 // recherche de la ligne dont la dernière carte est la plus grande < c.valeur
 // => règle du jeu : on pose la carte sur la rangée dont la dernière carte est la plus proche en dessous
 for (int l = 0; l < 4; l++) { // on parcourt l'ensemble des lignes du plateau
  // Nombre de cartes présentes sur la rangée l
  int nb = nb_cartes_par_rangee[l];
  // Si la rangée n'est pas vide
  if (nb > 0) {
   // Valeur de la dernière carte (la plus à droite dans cette rangée)
   int valprec = plateau[l][nb - 1].numero;
   // Condition de placement : valprec doit être < carte jouée
   // et on veut la plus grande valprec possible pour maximiser l'ajustement
   if (valprec < c.numero && valprec > meilleure_valeur) {
    // Met à jour le meilleur candidat
    meilleure_valeur = valprec;
    // Ligne cible candidate
    ligne_cible = l;
   }
  }
  // parcours du plateau pour verif si une ligne est complète ou pas
  // (commentaire d'origine : ici la vérif ligne complète est faite plus bas)
 }
 // Si aucune ligne possible (carte plus petite que toutes les fins de lignes)
 if (ligne_cible == -1) {

  // Affichage des lignes et de leur contenu
  // Ici tu envoies juste "PLATEAU" au joueur (selon ton protocole réseau)
  envoyer_message(joueur->sock,"PLATEAU",0);

  // Le joueur doit choisir une ligne à ramasser
  int ligne = choisir_ligne(joueur);

  // calcul des boeufs ramassés
  // On somme toutes les têtes de boeufs sur la ligne choisie
  int total_boeufs = 0;
  for (int k = 0; k < nb_cartes_par_rangee[ligne]; k++) {
   total_boeufs += plateau[ligne][k].boeufs;
  }

  // Ajoute la pénalité (boeufs ramassés) au score du joueur
  joueur->score += total_boeufs;
  // Trace console côté serveur
  printf("Joueur %d ramasse la ligne %d (+%d boeufs)\n", joueur->id, ligne + 1, total_boeufs);

  // On "vide" logiquement la ligne
  nb_cartes_par_rangee[ligne] = 0;
  // La carte jouée devient la première carte de cette ligne
  plateau[ligne][0] = c;
  // La ligne contient maintenant 1 carte
  nb_cartes_par_rangee[ligne] = 1;
  // Fin de traitement dans ce cas
  return;
 }
 // cas ou la ligne est complète
 // cas où la ligne cible a déjà 5 cartes -> ligne complète
 if (ligne_cible != -1 && nb_cartes_par_rangee[ligne_cible] == 5) {
  // Annonce console : la ligne est pleine, donc le joueur ramasse la ligne
  printf("\n=== Ligne %d complète ! Joueur %d ramasse toutes les cartes ===\n", ligne_cible, joueur->id);
  // Message informatif au joueur concerné
  envoyer_message(joueur->sock,"INFO Vous ramassez la ligne car elle etait complète",0);
  // Accumulateur des boeufs sur la ligne complète
  int total_boeufs = 0;
  // calcul du score total
  for (int z = 0; z < nb_cartes_par_rangee[ligne_cible]; z++) {
   total_boeufs += plateau[ligne_cible][z].boeufs;
  }
  // Ajoute la pénalité au score du joueur
  joueur->score += total_boeufs;
  // Trace console
  printf("Joueur %d gagne %d boeufs\n", joueur->id, total_boeufs);
  // Message informatif (contenu assez proche du précédent, mais conservé tel quel)
  envoyer_message(joueur->sock,"INFO Vous récupérez des boeufs equivalents à la ligne ",0);
  // vider la ligne et placer la nouvelle carte comme première
  nb_cartes_par_rangee[ligne_cible] = 0;
  // Place c en première position
  plateau[ligne_cible][0] = c;
  // Ligne réinitialisée à 1 carte
  nb_cartes_par_rangee[ligne_cible] = 1;
  // Fin de traitement
  return;
 }

 // cas normal : ajouter c en fin de ligne
 // Position où ajouter la carte (prochaine case libre)
 int pos = nb_cartes_par_rangee[ligne_cible];
 // Ajoute la carte à la fin de la rangée cible
 plateau[ligne_cible][pos] = c;
 // Incrémente le compteur de cartes de cette rangée
 nb_cartes_par_rangee[ligne_cible] = pos + 1;
 // Trace console
 printf("Carte %d placée sur la ligne %d (position %d)\n", c.numero, ligne_cible+1, pos+1);
 // Message réseau informatif au joueur
 envoyer_message(joueur->sock,"on a placé la carte sur la nouvelle ligne",0);
}

/**
 *
 * @param joueur le joueur actuel dans notre phase de gameplay
 * @param c la carte en question qui est jouer
 * @param Lst_AutreJoueurs l'ensemble de nos joueurs
 * @param nbjoueur de même le nb de nos joueurs
 */
void placer_carte_V2(Joueur *joueur, Carte c , Joueur Lst_AutreJoueurs[] , int nbjoueur) // on part du principe que ya 2 joueurs pour l'instant
{
 // Ligne cible où placer c (ou -1 si aucune ligne valide)
 int ligne_cible = -1;
 // Mémorise la meilleure dernière valeur < c.numero
 int meilleure_valeur = -1;
 // ligne cible recherche
 for (int l = 0; l < 4; l++) {
  // nb cartes actuelles dans la rangée l
  int nb = nb_cartes_par_rangee[l];

  // Si rangée non vide
  if (nb > 0) {
   // Dernière carte de la rangée
   int last = plateau[l][nb - 1].numero;

   // Si on peut poser (last < c.numero) et que last est le meilleur candidat (maximal)
   if (last < c.numero && last > meilleure_valeur) {
    meilleure_valeur = last;
    ligne_cible = l;
   }
  }
 }

 // cas de la selection de la ligne si la carte a un niveau inf au autres cartes
 // => aucune ligne possible : le joueur doit choisir une ligne à ramasser
 if (ligne_cible == -1) {

  // Informer tous les autres joueurs
  // => message d'info : quelqu'un est en train de choisir une ligne
  envoyer_a_tous_sauf(Lst_AutreJoueurs, nbjoueur, joueur->id, "INFO Un joueur doit choisir une ligne");
  // => envoyer le plateau aux autres (pour qu'ils voient l'état en cours)
  envoyer_a_tous_sauf(Lst_AutreJoueurs, nbjoueur, joueur->id, "PLATEAU");


  // Attente de sa réponse EXCLUSIVEMENT pour lui
  // => si humain, on envoie le signal "DEMANDER_LIGNE" sur son socket
  if (!joueur->est_robot) {
   envoyer_message(joueur->sock, "DEMANDER_LIGNE", 0);
  }

  // Récupère la ligne choisie (IA ou humain selon choisir_ligne)
  int ligne = choisir_ligne(joueur);


  // Calcul score
  // => somme des boeufs sur la ligne ramassée
  int total_boeufs = 0;
  for (int k = 0; k < nb_cartes_par_rangee[ligne]; k++) {
   total_boeufs += plateau[ligne][k].boeufs;
  }
  // Ajoute pénalité au score
  joueur->score += total_boeufs;

  // Mise à jour plateau
  // Vider toute la ligne
  for (int k = 0; k < 6; k++) {
   plateau[ligne][k] = (Carte){0, 0, ETAT_JOUEE, -1};
  } // es que quand la carte est enlever de la ligne exmple j'ai 15 98 es que la 98 vas dans la pioche
    // ou il passe dans un état de jouer ?
    // (dans TON code, tu mets les cartes retirées comme ETAT_JOUEE et numero=0, donc elles ne retournent pas en pioche)
  // Place la carte jouée comme première carte de la ligne désormais vide
  plateau[ligne][0] = c;
  // La ligne contient maintenant 1 carte
  nb_cartes_par_rangee[ligne] = 1;

  // Informer tout le monde du résultat
  // => construit un message info "Joueur X a ramassé la ligne Y"
  char info[TAILLE_BUF];
  sprintf(info, "INFO Joueur %d a ramassé la ligne %d", joueur->id, ligne);
  // Envoie info à tout le monde
  envoyer_messages_a_tous(Lst_AutreJoueurs, nbjoueur, info);
  // Envoie le plateau mis à jour à tout le monde
  envoyer_messages_a_tous(Lst_AutreJoueurs, nbjoueur, "PLATEAU");


  // Fin de cas ligne obligatoire
  return;
 }
 // Si la rangée cible est pleine (5 cartes), le joueur ramasse automatiquement
 if (nb_cartes_par_rangee[ligne_cible] == 5) {

  // Informer les autres
  // => message indiquant le ramassage automatique dû à rangée complète
  char info[TAILLE_BUF];
  sprintf(info, "INFO Joueur %d ramasse la ligne %d (ligne complète)", joueur->id, ligne_cible+1);
  envoyer_messages_a_tous(Lst_AutreJoueurs,nbjoueur,info);

  // Calcul score
  // => somme des boeufs des 5 cartes sur cette ligne
  int total = 0;
  for (int i = 0; i < nb_cartes_par_rangee[ligne_cible]; i++)
  {
   total += plateau[ligne_cible][i].boeufs;
  }
  // Ajoute pénalité au score du joueur
  joueur->score += total;

  // Réinitialisation
  // => vide la ligne (6 cases remises à "vide"/jouée)
  for (int k = 0; k < 6; k++) {
   plateau[ligne_cible][k] = (Carte){0, 0, ETAT_JOUEE, -1};
  }
  // Place la nouvelle carte comme première carte de la ligne
  plateau[ligne_cible][0] = c;
  // La ligne contient 1 carte
  nb_cartes_par_rangee[ligne_cible] = 1;

  // Envoie plateau à tout le monde
  envoyer_messages_a_tous(Lst_AutreJoueurs,nbjoueur,"PLATEAU");
  // Fin de traitement
  return;
 }


 // Cas normal : la ligne cible existe et n'est pas pleine
 // pos = index où poser la carte (fin de rangée)
 int pos = nb_cartes_par_rangee[ligne_cible];
 // Place la carte à la fin de la rangée cible
 plateau[ligne_cible][pos] = c;
 // Incrémente le compteur de cartes sur cette rangée
 nb_cartes_par_rangee[ligne_cible]++;

 // Construit une info textuelle "Joueur X place Y sur ligne Z"
 char info[128];
 sprintf(info, "INFO Joueur %d place %d sur la ligne %d", joueur->id, c.numero, ligne_cible);
 // Envoie info à tous
 envoyer_messages_a_tous(Lst_AutreJoueurs,nbjoueur,info);

 // Envoie plateau mis à jour à tous
 envoyer_messages_a_tous(Lst_AutreJoueurs,nbjoueur,"PLATEAU");
}

long ms(void) {
 // Structure timespec : secondes + nanosecondes
 struct timespec tv;
 // Horloge monotonic : ne recule pas si l’heure système change (parfait pour mesurer des durées)
 clock_gettime(CLOCK_MONOTONIC, &tv);
 // Convertit en millisecondes : sec*1000 + nsec/1e6
 return tv.tv_sec * 1000 + tv.tv_nsec / 1000000;
}
void Manche_Jeux() {

 // stats du temps
 // Buffer texte pour sérialiser l'état du plateau
 char Buff_plateau[TAILLE_BUF];
 // Buffer texte pour sérialiser la main d'un joueur
 char Buff_cartes[TAILLE_BUF];
 // Tableau des cartes jouées pendant un tour (1 par joueur)
 Carte cartes_jouees[MAX_Joueur];
 // Buffer pour infos de tour (ici surtout memset + debug, mais pas forcément utilisé)
 char Buff_tours[TAILLE_BUF];
 // Buffer texte pour sérialiser les scores
 char Buff_score[TAILLE_BUF]; //= {0}; // on reinitialcise a 02 a chaque fois ?/
 // Ouvre un fichier de log en mode append (ajout à la fin)
 FILE *logf = fopen("game.log", "a"); if (!logf) {
  // Si ouverture échoue : affiche erreur système
  perror("fopen game.log");
  // Termine le programme
  exit(1);
 }
 // Trace console serveur : fichier log ok
 printf("[DEBUG] game.log ouvert avec succès\n");
 // Petit marqueur debug dans le fichier
 fprintf(logf, "DEBUG_TEST\n");
 // Force écriture immédiate (évite de perdre si crash)
 fflush(logf);

 // Début d'une partie (id fixé à 1 ici)
 fprintf(logf, "PARTIE_START id=%d\n", 1); // faire une structure de partie ? pour la gestion des stats ?
 // TODO changer le 1 par id_partie qui est l'id de la partie faire une structure ?
 fflush(logf);

 // Log de chaque joueur : id + type (robot/humain)
 for (int i = 0; i < nb_joueurs; i++) {
  fprintf(logf, "JOUEUR id=%d type=%s\n",Lst_joueur[i].id,Lst_joueur[i].est_robot ? "robot" : "humain");
 }
 // Flush après boucle
 fflush(logf);

 // Message console : début de manche
 printf("\n Début de la manche \n");
 // Une manche = plusieurs tours
 // Ici : 9 tours (si Carte_par_Joueur = 10, ça veut dire que tu ne joues pas la 10ème carte dans ce code)
 for (int tour = 0; tour < 9; tour++) {
  // TODO ajouter un affichage des tours pour les deux joueurs
  // TODO affichage du score
  //printf("on vide les deux buffers de carte et de plateau");
  // Log du numéro de tour (commence à 1 dans le fichier)
  fprintf(logf, "TOUR num=%d\n", tour + 1);
  // Flush pour garantir écriture
  fflush(logf);

  // Réinitialise le buffer plateau (mise à 0)
  memset(Buff_plateau, 0, sizeof(Buff_plateau));
  // Réinitialise le buffer main
  memset(Buff_cartes, 0, sizeof(Buff_cartes));
  // Réinitialise le buffer tours
  memset(Buff_tours, 0, sizeof(Buff_tours));


  // Affiche le tour côté serveur
  printf("\nTOUR %d \n", tour + 1);
  // Convertit plateau -> texte protocole
  convertir_plateau_en_char(Buff_plateau);
  // Envoie le plateau à tous les joueurs connectés
  envoyer_messages_a_tous(Lst_joueur,nb_joueurs,Buff_plateau);
  // Tableau qui stocke, pour chaque joueur, l'indice de la carte choisie dans sa main
  int choix_joueur[MAX_Joueur];



  // boucle principale
  // Pour chaque joueur : envoi main, demande carte, récup choix
  for (int i = 0; i < nb_joueurs; i++) {
   // Construit le message MAIN pour le joueur i
   convertir_carte_en_char(&Lst_joueur[i], Buff_cartes);
   //verification des types de joueurs

   // Si joueur humain (socket valide)
   if (Lst_joueur[i].sock >= 0) {
    // Envoie sa main
    envoyer_message(Lst_joueur[i].sock, Buff_cartes, 0);
    // Trace serveur : on envoie la demande de carte
    printf("envoie du message, demander carte au sock %d\n",Lst_joueur[i].sock);
    // Demande au client de répondre avec une carte
    envoyer_message(Lst_joueur[i].sock, "DEMANDER_CARTE", 0);
   }
   // Log timestamp au moment où on demande la carte (mesure du temps de réponse)
   fprintf(logf,"DEMANDER_CARTE joueur=%d time=%ld\n",Lst_joueur[i].id, ms());// activation du temps
   // Flush
   fflush(logf);
   // Récupère la réponse (robot ou humain via réseau)
   choix_joueur[i] = choisir_carte(&Lst_joueur[i]);
   // Log timestamp au moment où on a la réponse (peut permettre de calculer un delta)
   fprintf(logf,"REPONSE_CARTE joueur=%d time=%ld\n",Lst_joueur[i].id, ms()); // pour le calcul du delta
   // Flush
   fflush(logf);


   // Vérification anti hors-borne : si indice invalide, on prend 0 (sécurité)
   if (choix_joueur[i] < 0 || choix_joueur[i] >= Lst_joueur[i].nb_cartes) {
    printf("Indice hors borne (joueur %d), on prend 0\n", Lst_joueur[i].id);
    choix_joueur[i] = 0;
   }
   // Enregistre la carte jouée
   // => on copie la carte choisie depuis la main du joueur dans le tableau cartes_jouees
   cartes_jouees[i] = Lst_joueur[i].cartes[choix_joueur[i]];
   // On attache l'id du joueur à la carte jouée (utile après tri)
   cartes_jouees[i].joueur_id = Lst_joueur[i].id;
   // Marque la carte comme jouée dans la main (elle ne doit plus être jouable)
   Lst_joueur[i].cartes[choix_joueur[i]].etat = ETAT_JOUEE;

   // Log : joueur X joue carte Y et valeur boeufs
   fprintf(logf,"JOUE joueur=%d carte=%d boeufs=%d\n",Lst_joueur[i].id,cartes_jouees[i].numero,cartes_jouees[i].boeufs);
   // Flush
   fflush(logf);

   // Affichage console serveur
   printf("Joueur %d joue la carte %d (%d boeufs)\n",Lst_joueur[i].id,cartes_jouees[i].numero,cartes_jouees[i].boeufs);

  }

  // Tri des cartes jouées
  // => important : le placement se fait dans l'ordre croissant des cartes jouées
  trier_carte(cartes_jouees, nb_joueurs);

  // Placement dans l'ordre
  // Pour chaque carte dans l’ordre trié : retrouver le joueur correspondant, puis placer
  for (int i = 0; i < nb_joueurs; i++) {
   for (int j = 0; j < nb_joueurs; j++) {
    // On identifie quel joueur a joué cette carte (par comparaison d'id)
    if (Lst_joueur[j].id == cartes_jouees[i].joueur_id) {
     // Place la carte sur le plateau (version V2 qui notifie tout le monde)
     placer_carte_V2(&Lst_joueur[j], cartes_jouees[i],Lst_joueur,nb_joueurs );
     break;
    }
   }
  }

  //Mise à jour du nombre de cartes
  // => compacte la main en supprimant les cartes jouées et met à jour nb_cartes
  for (int i = 0; i < nb_joueurs; i++) {
   Lst_joueur[i].nb_cartes = mise_a_jour_carte_joueur(Lst_joueur[i].cartes, Lst_joueur[i].nb_cartes);
  }
  // on envoie le score a chaque fin de manche
  // => convertit score -> texte
  convertir_score_en_char(Lst_joueur, Buff_score);
  // => envoie à tous
  envoyer_messages_a_tous(Lst_joueur,nb_joueurs,Buff_score);
  // log scores
  for (int i = 0; i < nb_joueurs; i++) {
   fprintf(logf,"SCORE joueur=%d total=%d\n",Lst_joueur[i].id,Lst_joueur[i].score);
  }
  // flush final du tour
  fflush(logf);

 }

}



void Partie()
{
 // Ouvre (append) le fichier de log global de la partie
 FILE *logf = fopen("game.log", "a");
 // Si erreur d'ouverture : message système + arrêt
 if (!logf) {
  perror("fopen game.log");
  exit(1);
 }
 // Compteur de fin (quand un joueur atteint 66)
 int fin = 0;
 // Numéro de manche (commence à 1)
 int manche = 1;
 // Boucle principale : tant que pas fini ET qu’on n’a pas dépassé NB_manche
 while (!fin && manche <= NB_manche)
 {
  // Joue une manche (plusieurs tours)
  Manche_Jeux();
  // Vérifie condition d'arrêt : un joueur atteint 66 ou plus
  for (int i = 0; i < nb_joueurs; i++) {
   if (Lst_joueur[i].score >= 66 ) {
    fin ++;// verif du score des joueurs et donc la fin du jeu
   }
  }
  // Debug : affiche la manche en cours
  printf("Manche Global=%d\n",manche);
  // Réinitialise le plateau pour la manche suivante
  Initialisation_Plateaux();
  // Réinitialise le paquet de cartes (toutes cartes à ETAT_PIOCHE)
  Initialisation_Carte();
  // Distribue de nouvelles mains
  distribuer_cartes();
  // Passe à la manche suivante
  manche++;
 }

 // fin de partie
 // Message console serveur
 printf("\n FIN DE LA PARTIE \n");
 // Notifie tous les joueurs que la partie est terminée
 envoyer_messages_a_tous(Lst_joueur,nb_joueurs,"FIN");// on notifie la fin de la game a tout les joueurs
 // TODO il faut faire ici la mise en place de l'affichage du score des joueurs dans les deux clients

 // On cherche le gagnant = score minimal (dans "6 qui prend", moins de boeufs = mieux)
 int meilleur = 999;
 int gagnant = -1;
 for (int i = 0; i < nb_joueurs; i++) {
  // Si ce joueur a un score plus faible que le meilleur actuel
  if (Lst_joueur[i].score < meilleur) {
   meilleur = Lst_joueur[i].score;
   gagnant = Lst_joueur[i].id;
  }
 }

 // en fin de game
 // Log fin de partie : gagnant + meilleur score
 fprintf(logf, "PARTIE_END gagnant=%d avec le score de %d\n", gagnant,meilleur);// TODO changer ça pour que ce soit exploitable
 // Flush avant fermeture
 fflush(logf);
 // Ferme le fichier log
 fclose(logf);

 // Affiche le gagnant côté serveur
 printf("Le gagnant est le Joueur %d avec %d têtes de boeufs !\n", gagnant, meilleur);
}