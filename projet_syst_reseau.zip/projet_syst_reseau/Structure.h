#ifndef PROJET_STRUCTURE_H
#define PROJET_STRUCTURE_H

/* =========================================================================
 * Structure.h : définitions des types et constantes utilisés dans le projet
 * ========================================================================= */

#include <stddef.h>

/* ====================== CONSTANTES ====================== */
#define Carte_par_Joueur 10   /* Nombre maximum de cartes qu’un joueur peut avoir */

/* ====================== ENUMERATIONS ====================== */

/* État d’une carte dans le jeu */
typedef enum {
    ETAT_PIOCHE,    /* Carte pas encore distribuée, dans la pioche */
    ETAT_MAIN,      /* Carte distribuée à un joueur */
    ETAT_PLATEAU,   /* Carte sur le plateau */
    ETAT_JOUEE      /* Carte jouée pendant un tour ou défaussée */
} EtatCarte;

/* Modes de jeu disponibles */
typedef enum {
    MODE_JVJ = 1,       /* Joueur contre Joueur */
    MODE_JVROBOT = 2    /* Joueur contre Robot */
} ModeJeu;

/* ====================== STRUCTURES ====================== */

/* Représente une carte individuelle */
typedef struct {
    int numero;      /* Numéro unique de la carte (1 à 104) */
    int boeufs;      /* Nombre de têtes de bœufs associé, compte pour le score */
    EtatCarte etat;  /* État actuel de la carte */
    int joueur_id;   /* ID du joueur propriétaire, -1 si aucun */
} Carte;

/* Représente un joueur */
typedef struct {
    Carte cartes[Carte_par_Joueur];  /* Cartes en possession du joueur */
    int id;                           /* ID unique du joueur */
    int score;                        /* Score actuel du joueur */
    int nb_cartes;                     /* Nombre de cartes actuellement en main */
    int sock;                         /* Socket associé si joueur réseau, -1 sinon */
    int est_robot;                     /* 0 = humain, 1 = robot */
} Joueur;

#endif /* PROJET_STRUCTURE_H */