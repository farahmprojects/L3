#ifndef GESTIONNAIRE_JEUX_H
#define GESTIONNAIRE_JEUX_H

/* =========================================================================
 * Gestionnaire_Jeux.h : prototypes et constantes pour la gestion du jeu
 * ========================================================================= */

#include "Structure.h"  // Pour les types Joueur, Carte, ModeJeu, etc.

/* ====================== CONSTANTES DU JEU ====================== */
#define MAX_Joueur 2              /* Nombre maximum de joueurs */
#define Nb_Carte_Totale 104       /* Nombre total de cartes dans le jeu */
#define TAILLE_BUF 256            /* Taille des buffers pour messages */
#define NB_manche 2               /* Nombre de manches par partie */
#define PORT 5050                 /* Port par défaut pour le serveur */
#define SCORE_LIMITE 66           /* Score limite pour déterminer le perdant */

/* ====================== VARIABLES GLOBALES ====================== */
extern int nb_joueurs;                      /* Nombre réel de joueurs dans la partie */
extern Joueur Lst_joueur[MAX_Joueur];       /* Liste des joueurs */
extern Carte carte[Nb_Carte_Totale];        /* Tableau des cartes du jeu */
extern Carte plateau[4][6];                 /* Plateau de jeu (4 lignes, 6 cartes max par ligne) */
extern ModeJeu mode_jeu;                    /* Mode de jeu sélectionné */

/* ====================== INITIALISATION ====================== */
/* Initialisation du plateau avec les cartes existantes */
void Initialisation_Plateaux();
/* Initialise un plateau vide */
void Initialisation_Plateaux_vide();
/* Initialise les joueurs avec leurs sockets ou IDs */
void Initalisation_Joueur(int client[]);
/* Initialise le jeu avec toutes les cartes */
void Initialisation_Carte();

/* ====================== AFFICHAGE ====================== */
/* Affiche l'état complet du plateau */
void Afficher_Plateaux();
/* Affiche toutes les cartes disponibles */
void Afficher_carte();
/* Affiche le score de tous les joueurs */
void Afficher_score();
/* Affiche l'état des cartes d'un joueur */
void afficher_etat_cartes();
/* Affiche l'état d'une carte spécifique */
void afficher_etat_de_la_carte(Carte c);

/* ====================== GESTION DES CARTES ====================== */
/* Trie un tableau de cartes en fonction du numéro */
void trier_carte(Carte cartes[], int n);
/* Place une carte sur le plateau (ancienne version) */
void placer_carte(Joueur *joueur, Carte c);
/* Place une carte sur le plateau (version améliorée avec notifications aux autres joueurs) */
void placer_carte_V2(Joueur *joueur, Carte c, Joueur Lst_AutreJoueurs[], int nbjoueur);
/* Met à jour la main d’un joueur après un tour */
int mise_a_jour_carte_joueur(Carte main_joueur[], int nb_cartes);
/* Calcule le nombre de bœufs d'une carte */
int calculer_boeufs(Carte *c);
/* Tire une carte non utilisée dans le jeu */
int tirer_carte_non_utilisee();
/* Tire une carte aléatoire */
int tirer_carte_alea();
/* Calcule le score d'une ligne spécifique sur le plateau */
int Score_Ligne(int ligne);

/* ====================== LOGIQUE PRINCIPALE ====================== */
/* Joue une manche complète (10 tours) */
void Manche_Jeux();
/* Gère plusieurs manches et conditions de victoire */
void Partie();

/* ====================== CONVERSION POUR RESEAU ====================== */
/* Convertit les cartes d’un joueur en chaîne de caractères */
void convertir_carte_en_char(Joueur *j, char *msg);
/* Convertit l'état du plateau en chaîne de caractères */
void convertir_plateau_en_char(char *plateau_msg);
/* Convertit le score d’un joueur en chaîne de caractères */
void convertir_score_en_char(Joueur *j, char *msg);

/* ====================== IA / ROBOT ====================== */
/* Robot choisit une carte à jouer */
int robot_choisir_carte(Joueur *j);
/* Robot choisit une ligne sur le plateau */
int robot_choisir_ligne(Joueur *j);
/* Interface pour choisir une carte (robot ou humain) */
int choisir_carte(Joueur *j);
/* Interface pour choisir une ligne (robot ou humain) */
int choisir_ligne(Joueur *j);

#endif /* GESTIONNAIRE_JEUX_H */
