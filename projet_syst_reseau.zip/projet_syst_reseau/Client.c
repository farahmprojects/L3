#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Reseau.h"
#include "Gestionnaire_Jeu.h"

// ---------------------------
// Affichage du plateau reçu depuis un message serveur
// ---------------------------
void afficher_plateau_depuis_message(const char *msg) {
    const char *p = strstr(msg, "\n");   // Cherche le premier saut de ligne après "PLATEAU"
    if (p) p++;                          // Avance le pointeur pour passer le \n

    printf("\n=== Plateau reçu ===\n");
    if (p)
        printf("%s\n", p);               // Affiche le contenu après "PLATEAU"
    else
        printf("%s\n", msg);             // Sécurité si "PLATEAU" n’est pas trouvé
    printf("====================\n");
}

// ---------------------------
// Affichage du score reçu depuis un message serveur
// ---------------------------
void afficher_score_depuis_message(const char *msg) {
    const char *p = strstr(msg, "\n");   // Cherche le saut de ligne après "SCORE"
    if (p) p++;                          // Avance le pointeur pour passer le \n

    printf("\n=== Score Message ===\n");
    if (p)
        printf("%s\n", p);               // Affiche le score
    else
        printf("%s\n", msg);             // Sécurité
    printf("===================\n");
}

// ---------------------------
// Affichage de la main du joueur depuis un message serveur
// ---------------------------
void afficher_main_depuis_message(const char *msg) {
    const char *p = strstr(msg, "\n");   // Cherche le saut de ligne après "MAIN"
    if (p) p++;

    printf("\n TA MAIN \n");
    if (p)
        printf("%s\n", p);               // Affiche les cartes
    else
        printf("%s\n", msg);
}

// ---------------------------
// Affichage d’informations générales depuis un message serveur
// ---------------------------
void afficher_info(const char *msg) {
    const char *p = strstr(msg, "\n");   // Cherche le saut de ligne après "INFO"
    if (p) p++;

    printf("\n Info Message \n");
    if (p)
        printf("%s\n", p);               // Affiche le message
    else
        printf("%s\n", msg);
}

// ---------------------------
// Gestion des messages reçus depuis le serveur
// ---------------------------
void traiter_message_serveur(int sockfd, char *buffer) {

    // ---------------------------
    // Affichage du plateau (si nécessaire)
    // ---------------------------
    if (strncmp(buffer, "PLATEAU", 7) == 0) {
        //afficher_plateau_depuis_message(buffer);
    }

    // ---------------------------
    // Affichage d'informations générales
    // ---------------------------
    else if (strncmp(buffer, "INFO", 4) == 0) {
        afficher_info(buffer);
    }

    // ---------------------------
    // Affichage de la main du joueur
    // ---------------------------
    else if (strncmp(buffer, "MAIN", 4) == 0) {
        //afficher_main_depuis_message(buffer);
    }

    // ---------------------------
    // Affichage du score
    // ---------------------------
    else if (strncmp(buffer, "SCORE", 5) == 0) {
        //afficher_score_depuis_message(buffer);
    }

    // ---------------------------
    // Demande de choix de carte au joueur
    // ---------------------------
    else if (strncmp(buffer, "DEMANDER_CARTE", 14) == 0) {
        char input[32];
        printf("Choisis une carte : ");
        fgets(input, sizeof(input), stdin);     // Lecture sécurisée
        int choix = atoi(input);                // Conversion en entier
        sprintf(buffer, "CARTE %d", choix);     // Prépare le message à envoyer
        envoyer_message(sockfd, buffer, strlen(buffer));
    }

    // ---------------------------
    // Demande de choix de ligne au joueur
    // ---------------------------
    else if (strncmp(buffer, "DEMANDER_LIGNE", 14) == 0) {
        char input[32];
        printf("Choisis la ligne à ramasser (0-3) : ");
        fgets(input, sizeof(input), stdin);
        int choix = atoi(input);
        sprintf(buffer, "LIGNE %d", choix);
        envoyer_message(sockfd, buffer, strlen(buffer));
    }

    // ---------------------------
    // Fin de la partie
    // ---------------------------
    else if (strncmp(buffer, "FIN", 10) == 0) {
        printf("La partie est terminée !\n");
        exit(0);   // Sortie immédiate du programme
    }
}

// ---------------------------
// Fonction principale
// ---------------------------
int main() {
    int sockfd = connexion_serveur("127.0.0.1", 5050);  // Connexion au serveur
    char buffer[TAILLE_BUF];                             // Buffer pour réception messages

    while (1) {
        // ---------------------------
        // Nettoyage du buffer avant chaque réception
        // ---------------------------
        memset(buffer, 0, sizeof(buffer));

        int n = recevoir_message(sockfd, buffer, TAILLE_BUF);  // Lecture message
        if (n <= 0) {
            printf("[DEBUG SORTIE DU PROG PROBLEME DE MESSAGE RECU]");
            break;   // Sortie si déconnexion ou erreur
        }

        if (n > 0) {
            buffer[n] = '\0';    // Terminaison de chaîne
            // ---------------------------
            // Gestion de plusieurs messages reçus simultanément
            // ---------------------------
            char *ligne = strtok(buffer, "\n");
            while (ligne != NULL) {
                //printf("[DEBUG CLIENT] Message traité: '%s'\n", buffer);
                traiter_message_serveur(sockfd, ligne);  // Traitement ligne par ligne
                ligne = strtok(NULL, "\n");               // Passage à la ligne suivante
            }
        }
    }

    // ---------------------------
    // Fermeture de la socket client
    // ---------------------------
    close(sockfd);   // Note : probablement `close` sur Linux

    // Fermeture des sockets des joueurs si nécessaire
    /*
    for (int i =0 ; i< nb_joueurs; i++) {
        close(Lst_joueur[i].sock);
    }
    */
    // return 0;
}
