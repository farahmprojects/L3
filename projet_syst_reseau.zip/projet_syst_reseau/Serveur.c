#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <time.h>
#include "Gestionnaire_Jeu.h"
#include "Reseau.h"

// ---------------------------
// Fonction principale
// ---------------------------
int main() {
    int sockfd;                      // Descripteur de la socket serveur
    int clients[MAX_Joueur];         // Tableau des sockets clients connectés

    // ---------------------------
    // Initialisation du générateur de nombres aléatoires
    // ---------------------------
    srand(time(NULL));

    // ---------------------------
    // Écriture du log pour signaler le lancement du serveur
    // ---------------------------
    FILE *logf = fopen("game.log", "a");      // Ouverture en mode ajout
    fprintf(logf, "SERVEUR_LANCE\n");         // Écriture du message
    fflush(logf);                             // Forcer l'écriture immédiate
    fclose(logf);                             // Fermeture du fichier

    // ---------------------------
    // Affichage du menu et lecture du choix de mode de jeu
    // ---------------------------
    printf("Choisissez le mode de jeu :\n");
    printf(" Version : Joueur vs Joueur --> tapez 1\n");
    printf(" Version : Joueur vs Robot --> tapez 2\n");

    char input[32];                          // Buffer pour la saisie utilisateur
    printf("Choisissez un mode de jeu  : ");
    fgets(input, sizeof(input), stdin);      // Lecture sécurisée de l'entrée
    int choix = atoi(input);                 // Conversion en entier

    // ---------------------------
    // Détermination du mode de jeu selon le choix
    // ---------------------------
    if (choix == 2)
        mode_jeu = MODE_JVROBOT;            // Humain contre robot
    else
        mode_jeu = MODE_JVJ;                // Humain contre humain

    printf(" 111 [DEBUG] nb_joueurs = %d\n", nb_joueurs);  // Debug du nombre de joueurs initial

    // ---------------------------
    // Définition du nombre de joueurs selon le mode
    // ---------------------------
    if (mode_jeu == MODE_JVJ)
        nb_joueurs = 2;                      // Deux joueurs humains
    else
        nb_joueurs = 2;                      // Un humain + un robot (logique interne)

    // ---------------------------
    // Création de la socket serveur
    // ---------------------------
    sockfd = creer_socket_serveur(5050);     // Création d'une socket sur le port 5050

    // ---------------------------
    // Connexion des joueurs
    // ---------------------------
    if (mode_jeu == MODE_JVJ) {
        attendre_connexion_joueurs(sockfd, 2, clients); // Deux humains
    } else {
        attendre_connexion_joueurs(sockfd, 1, clients); // Un seul humain
    }

    printf("222[DEBUG] nb_joueurs = %d\n", nb_joueurs);  // Debug après connexion

    // ---------------------------
    // Initialisation du jeu : cartes et plateaux
    // ---------------------------
    Initialisation_Carte();                  // Préparer le paquet de cartes
    Initialisation_Plateaux();               // Préparer les plateaux de jeu

    // ---------------------------
    // Création des joueurs (humains et robot si nécessaire)
    // ---------------------------
    Initalisation_Joueur(clients);           // Initialisation des joueurs

    // ---------------------------
    // Lancement de la partie
    // ---------------------------
    Partie();                                // Fonction principale de gestion de la partie

    // ---------------------------
    // Fermeture des sockets des joueurs pour libérer les ressources
    // ---------------------------
    for (int i = 0; i < nb_joueurs; i++) {
        close(Lst_joueur[i].sock);           // Fermeture de chaque socket joueur
    }

    return 0;                                // Fin du programme
}
