BEGIN {
    print "\\documentclass{article}"
    print "\\usepackage[utf8]{inputenc}"
    print "\\title{Statistiques de la partie}"
    print "\\date{}"
    print "\\begin{document}"
    print "\\maketitle"
    print "\\section*{Résumé}"
}

/^DEMANDER_CARTE/ {
    for (i=1; i<=NF; i++) {
        if ($i ~ /^joueur=/) {
            split($i,a,"="); j=a[2]
        }
        else if ($i ~ /^time=/) {
            split($i,b,"="); t=b[2]
        }
    }
    demande_time[j] = t
}
/^REPONSE_CARTE/ {
    for (i=1; i<=NF; i++) {
        if ($i ~ /^joueur=/) {
            split($i,a,"="); j=a[2]
        }
        else if ($i ~ /^time=/) {
            split($i,b,"="); t=b[2]
        }
    }

    if (j in demande_time) {
        delta = t - demande_time[j]
        total_temps[j] += delta
        nb_reponses[j]++
        delete demande_time[j]
    }
}

/^JOUE/ {
    joueur = carte = boeufs = ""

    for (i = 1; i <= NF; i++) {
        if ($i ~ /^joueur=/) {
            split($i, a, "=")
            joueur = a[2]
        }
        else if ($i ~ /^carte=/) {
            split($i, b, "=")
            carte = b[2]
        }
    }

    cartes_jouees[joueur]++
    somme_cartes[joueur] += carte

    if (cartes_liste[joueur] == "")
        cartes_liste[joueur] = carte
    else
        cartes_liste[joueur] = cartes_liste[joueur] ", " carte
}


/^SCORE/ {
    for (i = 1; i <= NF; i++) {
        if ($i ~ /^joueur=/) {
            split($i, a, "="); joueur = a[2]
        }
        if ($i ~ /^total=/) {
            split($i, b, "="); total[joueur] = b[2]
        }
    }
}

/^PARTIE_END/ {
    for (i = 1; i <= NF; i++) {
        if ($i ~ /^gagnant=/) {
            split($i, a, "="); gagnant = a[2]
            victoires[gagnant]++
        }
    }
    parties++
}

END {
    print "\\section*{Statistiques par joueur}"

    for (j in total) {
        if (cartes_jouees[j] > 0)
            moyenne_cartes = somme_cartes[j] / cartes_jouees[j]
        else
            moyenne_cartes = 0

        print "\\subsection*{Joueur " j "}"
        print "\\begin{itemize}"
        print "\\item Points(têtes de boeufs) : " total[j]
        print "\\item Victoires : " (victoires[j] + 0)
        print "\\item Nombre de cartes jouées : " (cartes_jouees[j] + 0)
        print "\\item Valeur moyenne des cartes : " moyenne_cartes
        print "\\end{itemize}"
        print "\\section*{Temps de réponse}"
            moyenne = total_temps[j] / nb_reponses[j]
            print "Joueur " j " : " moyenne " ms\\\\"
    }

    print "\\end{document}"
}
