#ifndef RESEAU_H
#define RESEAU_H

/* =========================================================================
 * Reseau.h : prototypes pour la couche réseau du jeu
 * Fournit les fonctions pour :
 *   - Création et gestion des sockets serveur et client
 *   - Envoi et réception de messages
 *   - Broadcast vers plusieurs joueurs
 *   - Interaction spécifique avec le jeu (demander carte/ligne)
 * ========================================================================= */

#include "Structure.h"
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>
#include <stddef.h>
#include <sys/types.h> /* pour ssize_t */

/* ====================== CONSTANTES ====================== */
#define PORT_DEFAULT 5050  // port par défaut pour le serveur
#define TAILLE_BUF 256     // taille des buffers de communication

/* ====================== FONCTIONS SERVEUR ====================== */

/**
 * Crée une socket serveur TCP sur le port fourni
 * @param port Le port d'écoute
 * @return Socket serveur (fd >= 0)
 */
int creer_socket_serveur(uint16_t port);

/**
 * Attend nb_joueurs connexions et stocke leurs sockets dans clients[]
 * @param sockfd Socket serveur
 * @param nb_joueurs Nombre de joueurs attendus
 * @param clients Tableau pour stocker les sockets clients
 * @return 0 si succès, -1 si erreur
 */
int attendre_connexion_joueurs(int sockfd, int nb_joueurs, int clients[]);

/* ====================== FONCTIONS CLIENT ====================== */

/**
 * Se connecte à un serveur TCP
 * @param ip_serveur Adresse IP du serveur
 * @param port Port du serveur
 * @return Socket connecté ou -1 en cas d'erreur
 */
int connexion_serveur(const char *ip_serveur, uint16_t port);

/* ====================== COMMUNICATION (UTILITAIRES) ====================== */

/**
 * Envoie un message sur le socket
 * @param sockfd Socket destinataire
 * @param message Message à envoyer
 * @param taille Taille du message (0 = calcul via strlen)
 * @return Nombre d'octets envoyés ou -1 en cas d'erreur
 */
ssize_t envoyer_message(int sockfd, const char *message, size_t taille);

/**
 * Reçoit un message depuis le socket
 * @param sockfd Socket source
 * @param buffer Buffer pour stocker le message
 * @param taille Taille du buffer
 * @return Nombre d'octets reçus, 0 si fermeture, -1 si erreur
 */
ssize_t recevoir_message(int sockfd, char *buffer, size_t taille);

/**
 * Wrapper pratique pour envoyer un buffer formaté (similaire à printf)
 */
int envoyer_printf(int sock, const char *buffer);

/* ====================== BROADCAST / ENVOI À PLUSIEURS ====================== */

/**
 * Envoie un message à tous sauf au joueur avec id_exclu
 * @param liste Tableau des joueurs
 * @param nb Nombre de joueurs
 * @param id_exclu ID du joueur à exclure
 * @param msg Message à envoyer
 */
void envoyer_a_tous_sauf(const Joueur liste[], int nb, int id_exclu, const char *msg);

/**
 * Envoie un message à tous les joueurs
 * @param liste Tableau des joueurs
 * @param nb Nombre de joueurs
 * @param msg Message à envoyer
 */
void envoyer_messages_a_tous(const Joueur liste[], int nb, const char *msg);

/**
 * Optionnel : envoi global à tous les joueurs
 */
void broadcast(const char *msg, const Joueur liste[], int nb);

/* ====================== INTERACTIONS SPÉCIFIQUES AU JEU ====================== */

/**
 * Demande au joueur de choisir une carte
 * @param sock Socket du joueur
 * @param j Joueur associé
 * @return Indice de la carte choisie ou -1 si erreur
 */
int demander_carte_res(int sock, Joueur *j);

/**
 * Demande au joueur de choisir une ligne
 * @param sock Socket du joueur
 * @param j Joueur associé
 * @return Indice de ligne ou -1 si erreur
 */
int demander_ligne_res(int sock, Joueur *j);

#endif /* RESEAU_H */
